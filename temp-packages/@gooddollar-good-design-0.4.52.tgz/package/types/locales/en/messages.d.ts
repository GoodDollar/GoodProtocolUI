import type { Messages } from "@lingui/core";
export declare const messages: Messages;
//# sourceMappingURL=messages.d.ts.map