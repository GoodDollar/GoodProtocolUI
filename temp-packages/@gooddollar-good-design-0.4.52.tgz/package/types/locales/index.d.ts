export declare const defaultMessages: {
    en: import("@lingui/core").Messages;
    es: import("@lingui/core").Messages;
    "es-419": import("@lingui/core").Messages;
    fr: import("@lingui/core").Messages;
    hi: import("@lingui/core").Messages;
    id: import("@lingui/core").Messages;
    it: import("@lingui/core").Messages;
    ko: import("@lingui/core").Messages;
    pt: import("@lingui/core").Messages;
    tr: import("@lingui/core").Messages;
    uk: import("@lingui/core").Messages;
    vi: import("@lingui/core").Messages;
    zh: import("@lingui/core").Messages;
};
export declare const localeCodes: string[];
//# sourceMappingURL=index.d.ts.map