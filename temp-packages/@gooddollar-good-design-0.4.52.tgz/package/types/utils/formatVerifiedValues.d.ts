import { CredentialSubject, CredentialType } from "@gooddollar/web3sdk-v2";
export interface FormattedCertificate {
    credentialSubject: CredentialSubject | undefined;
    typeName: CredentialType;
    disputedSubjects?: string[];
}
export declare const formatVerifiedValues: ({ credentialSubject, typeName, disputedSubjects }: FormattedCertificate) => string;
//# sourceMappingURL=formatVerifiedValues.d.ts.map