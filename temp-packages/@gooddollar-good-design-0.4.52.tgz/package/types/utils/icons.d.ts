export declare const networkIcons: {
    FUSE: any;
    CELO: any;
    XDC: any;
    MAINNET: any;
    CELO_DARK: any;
};
export declare const getBridgeNetworkIcon: (chain: string) => any;
export declare const contractIcons: {
    GoodDollar: any;
};
export declare const getContractIcon: () => any;
export declare const getTransactionIcon: (transaction: any) => any;
export declare const getTxIcons: (transaction: any) => {
    txIcon: any;
    networkIcon: any;
    contractIcon: any;
};
//# sourceMappingURL=icons.d.ts.map