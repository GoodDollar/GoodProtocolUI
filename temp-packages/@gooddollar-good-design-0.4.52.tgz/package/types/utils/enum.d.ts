export declare const getKeyByValue: <T extends {
    [index: string]: string;
}>(enumObj: T, value: string) => keyof T | null;
//# sourceMappingURL=enum.d.ts.map