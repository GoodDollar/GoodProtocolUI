export declare const isTxReject: ({ message, code }: {
    message: string;
    code?: number | undefined;
}) => boolean;
//# sourceMappingURL=transactionType.d.ts.map