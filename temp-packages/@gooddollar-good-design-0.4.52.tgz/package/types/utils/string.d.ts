export declare const truncateMiddle: (string?: string, maxLength?: null | number, ellipsis?: string) => string;
//# sourceMappingURL=string.d.ts.map