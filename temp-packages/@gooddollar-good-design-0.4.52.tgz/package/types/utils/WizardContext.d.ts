import React from "react";
export type WizardContextValues = {
    data: {
        [key: string]: any;
    };
    setDataValue: (key: string, value: any) => void;
    updateDataValue: (baseKey: string, updateKey: string, value: any) => void;
};
export declare const WizardContext: React.Context<WizardContextValues>;
export declare const WizardContextProvider: ({ children }: {
    children: React.ReactNode;
}) => React.JSX.Element;
//# sourceMappingURL=WizardContext.d.ts.map