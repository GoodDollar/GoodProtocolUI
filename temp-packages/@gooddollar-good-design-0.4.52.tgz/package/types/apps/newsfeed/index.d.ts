export * from "./NewsFeed";
//# sourceMappingURL=index.d.ts.map