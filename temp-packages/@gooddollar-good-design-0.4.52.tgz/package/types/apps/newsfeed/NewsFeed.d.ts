import React from "react";
import { FeedPost } from "@gooddollar/web3sdk-v2";
export declare const NewsFeed: React.FC<{
    feed: FeedPost[];
    direction: "row" | "column";
    styles?: {
        item?: object | undefined;
    } | undefined;
} & import("native-base/lib/typescript/components/primitives/Stack/HStack").InterfaceHStackProps & {
    variant?: unknown;
    size?: import("native-base/lib/typescript/components/types").ThemeComponentSizeType<"HStack">;
    colorScheme?: import("native-base/lib/typescript/components/types").ColorSchemeType;
} & import("native-base/lib/typescript/components/primitives/Stack/VStack").InterfaceVStackProps & {
    variant?: unknown;
    size?: import("native-base/lib/typescript/components/types").ThemeComponentSizeType<"VStack">;
    colorScheme?: import("native-base/lib/typescript/components/types").ColorSchemeType;
}>;
//# sourceMappingURL=NewsFeed.d.ts.map