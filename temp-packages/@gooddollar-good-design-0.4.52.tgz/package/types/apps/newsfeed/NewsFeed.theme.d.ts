export declare const NewsFeed: {
    baseStyle: {
        containerStyles: {
            marginLeft: string;
            marginRight: string;
        };
    };
    variants: {
        multiRow: () => {
            styles: {
                item: {
                    width: string;
                    ml: string;
                    mr: string;
                    space: number;
                    display: string;
                    justifyContent: string;
                    flexWrap: string;
                };
            };
        };
    };
};
//# sourceMappingURL=NewsFeed.theme.d.ts.map