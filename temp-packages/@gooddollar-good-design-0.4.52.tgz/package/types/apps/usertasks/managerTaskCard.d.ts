import React, { FC } from "react";
export interface TaskReward {
    type: "points" | "tokens" | "badge";
    amount?: number;
    description: string;
}
export declare const useClaimerTasks: () => {
    mainTask: ClaimerTask | undefined;
    secondaryTasks: ClaimerTask[];
    loading: boolean;
    dismissing: boolean;
    hasActiveTasks: boolean;
    dismissTask: (taskId: string, skipToast?: boolean) => Promise<void>;
    dismissAllTasks: (taskIds: string[], onTaskDismiss?: ((taskId: string) => void) | undefined) => Promise<void>;
    completeTask: (taskId: string) => Promise<void>;
};
export interface ClaimerTask {
    type: "noTasks" | "activeTasks" | "secondaryTasks" | "modalContent" | "learn";
    taskId?: string;
    content?: string;
    id: string;
    title: string;
    description: string;
    category: "social" | "donation" | "referral" | "engagement";
    reward?: TaskReward;
    duration: {
        startDate: string;
        endDate: string;
    };
    actionUrl?: string;
    icon?: string;
    rewardAmount?: string;
    rewardColor?: string;
    priority?: "main" | "secondary";
}
interface ManagerTaskProps {
    type: ClaimerTask["type"];
    task?: ClaimerTask;
    isPending: boolean;
    customTitle?: string;
    onClose?: () => void;
    onPress?: () => void;
    fontStyles?: any;
}
export declare const ManagerTask: FC<ManagerTaskProps>;
interface ClaimerTasksCardProps {
    tasks?: ClaimerTask[];
    onTaskComplete?: (taskId: string) => void;
    onTaskDismiss?: (taskId: string) => void;
    fontStyles?: any;
    ContentComponent?: any;
    showAsModal?: boolean;
}
export declare const ClaimerTasksCard: React.FC<ClaimerTasksCardProps>;
export { ClaimerTasksCard as ClaimerTasksCompact };
//# sourceMappingURL=managerTaskCard.d.ts.map