import { ClaimerTask } from "./managerTaskCard";
export declare const SAMPLE_TASKS: ClaimerTask[];
//# sourceMappingURL=mockData.d.ts.map