import React from "react";
import type { MicroBridgeProps } from "../types";
export declare const BridgeWizard: ({ useCanBridge, onSetChain, originChain, inputTransaction, error, pendingTransaction, limits, fees, bridgeStatus, relayStatus, selfRelayStatus, onBridgeStart, onBridgeSuccess, onBridgeFailed, withRelay }: MicroBridgeProps) => React.JSX.Element;
//# sourceMappingURL=BridgeWizard.d.ts.map