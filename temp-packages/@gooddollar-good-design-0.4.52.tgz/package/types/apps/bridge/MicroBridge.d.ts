import React from "react";
import type { MicroBridgeProps } from "./types";
export declare const MicroBridge: ({ useCanBridge, onSetChain, originChain, inputTransaction, pendingTransaction, limits, fees, bridgeStatus, relayStatus, selfRelayStatus, onBridgeStart, onBridgeFailed, onBridgeSuccess }: MicroBridgeProps) => React.JSX.Element;
//# sourceMappingURL=MicroBridge.d.ts.map