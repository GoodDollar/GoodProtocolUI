import { TransactionStatus } from "@usedapp/core";
import type { BridgeTransaction } from "../types";
interface CreateTransactionDetailsParams {
    amountWei: string;
    sourceChain: string;
    targetChain: string;
    bridgeProvider: string;
    bridgeStatus: Partial<TransactionStatus> | undefined;
    bridgeToTxHash: string | undefined;
    date?: Date;
}
export declare const createTransactionDetails: (params: CreateTransactionDetailsParams) => BridgeTransaction;
export {};
//# sourceMappingURL=transactionHelpers.d.ts.map