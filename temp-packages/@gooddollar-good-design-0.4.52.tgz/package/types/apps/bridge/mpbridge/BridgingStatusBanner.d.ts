import React from "react";
interface BridgingStatusBannerProps {
    isBridging: boolean;
    bridgingStatus: string;
    isError?: boolean;
}
export declare const BridgingStatusBanner: React.FC<BridgingStatusBannerProps>;
export {};
//# sourceMappingURL=BridgingStatusBanner.d.ts.map