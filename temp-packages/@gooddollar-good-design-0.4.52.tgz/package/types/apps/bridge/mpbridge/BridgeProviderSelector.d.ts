import React from "react";
import type { BridgeProvider } from "./types";
interface BridgeProviderSelectorProps {
    bridgeProvider: BridgeProvider;
    onProviderChange: (provider: BridgeProvider) => void;
}
export declare const BridgeProviderSelector: React.FC<BridgeProviderSelectorProps>;
export {};
//# sourceMappingURL=BridgeProviderSelector.d.ts.map