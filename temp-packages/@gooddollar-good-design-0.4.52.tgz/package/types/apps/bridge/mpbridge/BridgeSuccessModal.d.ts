import React from "react";
import { BigNumber } from "ethers";
interface BridgeSuccessModalProps {
    open: boolean;
    onClose: () => void;
    data: {
        bridgeProvider: string;
        sourceChain: string;
        targetChain: string;
        amount: string;
        protocolFeePercent?: number;
        networkFee?: BigNumber;
        txHash?: string;
    };
    onTrackTransaction: () => void;
}
export declare const BridgeSuccessModal: ({ open, onClose, data, onTrackTransaction }: BridgeSuccessModalProps) => React.JSX.Element;
export {};
//# sourceMappingURL=BridgeSuccessModal.d.ts.map