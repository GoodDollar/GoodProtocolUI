import React from "react";
import type { BridgeTransaction } from "./types";
export type BridgeTransactionCardProps = {
    transaction: BridgeTransaction;
    onTxDetailsPress?: (transaction: BridgeTransaction) => void;
};
export declare const BridgeTransactionCard: React.FC<BridgeTransactionCardProps>;
type BridgeTransactionListProps = {
    transactions: BridgeTransaction[] | undefined;
    onTxDetailsPress?: (transaction: BridgeTransaction) => void;
    limit?: number;
};
export declare const BridgeTransactionList: ({ transactions, onTxDetailsPress, limit }: BridgeTransactionListProps) => React.JSX.Element;
export {};
//# sourceMappingURL=MPBBridgeTransactionCard.d.ts.map