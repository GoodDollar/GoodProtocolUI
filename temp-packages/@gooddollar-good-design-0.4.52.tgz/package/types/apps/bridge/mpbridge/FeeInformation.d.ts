import React from "react";
import type { BridgeProvider } from "./types";
export interface FeeInformationProps {
    sourceChain: string;
    targetChain: string;
    bridgeProvider: BridgeProvider;
    protocolFeePercent?: number;
    bridgeFees?: any;
    feesLoading?: boolean;
}
export declare const FeeInformation: React.FC<FeeInformationProps>;
//# sourceMappingURL=FeeInformation.d.ts.map