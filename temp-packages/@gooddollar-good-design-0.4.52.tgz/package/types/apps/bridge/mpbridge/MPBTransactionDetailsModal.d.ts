import React from "react";
import type { BridgeTransaction } from "./types";
interface MPBTransactionDetailsModalProps {
    open: boolean;
    onClose: () => void;
    transaction: BridgeTransaction;
    transactionHistory?: BridgeTransaction[];
}
export declare const MPBTransactionDetailsModal: ({ open, onClose, transaction, transactionHistory }: MPBTransactionDetailsModalProps) => React.JSX.Element;
export {};
//# sourceMappingURL=MPBTransactionDetailsModal.d.ts.map