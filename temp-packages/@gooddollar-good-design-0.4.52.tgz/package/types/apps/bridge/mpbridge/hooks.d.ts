import { CurrencyValue } from "@usedapp/core";
import type { IMPBFees, IMPBLimits, MPBBridgeHistoryChainIds, MPBBridgeReadOnlyUrls } from "./types";
export declare const useBridgeFees: () => {
    fees: any;
    loading: boolean;
    error: string | null;
};
export declare const useMPBBridgeEstimate: ({ limits, fees, sourceChain, inputWei }: {
    limits?: IMPBLimits | undefined;
    fees?: IMPBFees | undefined;
    sourceChain: string;
    inputWei: string;
}) => {
    expectedFee: CurrencyValue;
    expectedToReceive: CurrencyValue;
    minimumAmount: CurrencyValue;
    maximumAmount: CurrencyValue;
    bridgeFee: CurrencyValue;
    nativeFee: CurrencyValue;
    zroFee: CurrencyValue;
};
export declare const useChainBalances: (bridgeReadOnlyUrls?: MPBBridgeReadOnlyUrls) => {
    getBalanceForChain: (chain: string) => CurrencyValue;
};
export declare const useDebouncedTransactionHistory: (delay?: number, bridgeReadOnlyUrls?: MPBBridgeReadOnlyUrls, bridgeHistoryChainIds?: MPBBridgeHistoryChainIds) => {
    realTransactionHistory: any[] | undefined;
    historyLoading: boolean;
    historyRefreshing: boolean;
    historyErrorsByChain: Record<number, string>;
    refreshHistory: (() => void) | (() => void);
};
export declare const useConvertedTransactionHistory: (realTransactionHistory: any[] | undefined, sourceChain: string) => {
    chainId: number;
    network: string;
    displayName: string;
    contractName: string;
    contractAddress: any;
    account: any;
    type: string;
    isPool: boolean;
    date?: Date | undefined;
    id: any;
    transactionHash: any;
    sourceChain: string;
    targetChain: string;
    amount: any;
    bridgeProvider: string;
    status: string;
}[];
//# sourceMappingURL=hooks.d.ts.map