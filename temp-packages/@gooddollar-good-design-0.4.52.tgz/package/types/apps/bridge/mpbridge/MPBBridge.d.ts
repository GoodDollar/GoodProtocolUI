import React from "react";
import type { MPBBridgeProps } from "./types";
export declare const MPBBridge: (props: MPBBridgeProps) => React.JSX.Element;
//# sourceMappingURL=MPBBridge.d.ts.map