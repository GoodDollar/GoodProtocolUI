import React from "react";
import { CurrencyValue } from "@usedapp/core";
type ValidationReason = "minAmount" | "maxAmount" | "cannotBridge" | "error" | "insufficientBalance" | "invalidChain";
interface AmountInputProps {
    wei: string;
    gdValue: CurrencyValue;
    bridgeWeiAmount: string;
    setBridgeAmount: (amount: string) => void;
    minimumAmount: CurrencyValue;
    maximumAmount?: CurrencyValue;
    isValid: boolean;
    reason: ValidationReason;
    balance: CurrencyValue;
    toggleState?: any;
}
export declare const AmountInput: React.FC<AmountInputProps>;
export {};
//# sourceMappingURL=AmountInput.d.ts.map