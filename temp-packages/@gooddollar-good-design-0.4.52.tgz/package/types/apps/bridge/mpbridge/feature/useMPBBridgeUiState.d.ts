/// <reference types="react" />
export declare const useMPBBridgeUiState: () => {
    showSourceDropdown: boolean;
    setShowSourceDropdown: import("react").Dispatch<import("react").SetStateAction<boolean>>;
    showTargetDropdown: boolean;
    setShowTargetDropdown: import("react").Dispatch<import("react").SetStateAction<boolean>>;
    toggleState: boolean;
    setToggleState: import("react").Dispatch<import("react").SetStateAction<boolean>>;
    successModalOpen: boolean;
    setSuccessModalOpen: import("react").Dispatch<import("react").SetStateAction<boolean>>;
    errorMessage: string;
    setErrorMessage: import("react").Dispatch<import("react").SetStateAction<string>>;
    txDetailsOpen: boolean;
    txDetails: any;
    setTxDetails: import("react").Dispatch<any>;
    setTxDetailsOpen: import("react").Dispatch<import("react").SetStateAction<boolean>>;
    onTxDetailsPress: (tx: any) => void;
    onTxDetailsClose: () => void;
    closeAllDropdowns: () => void;
};
//# sourceMappingURL=useMPBBridgeUiState.d.ts.map