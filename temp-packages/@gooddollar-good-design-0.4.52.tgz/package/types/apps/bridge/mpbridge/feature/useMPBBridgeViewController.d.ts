import type { MPBBridgeProps, BridgeProvider } from "../types";
export interface MPBBridgeViewModel {
    modals: {
        txDetails: {
            shouldRender: boolean;
            props: {
                open: boolean;
                onClose: () => void;
                transaction: any;
                transactionHistory: any[];
            };
        };
        success: {
            open: boolean;
            onClose: () => void;
            data: any;
            onTrackTransaction: () => void;
        };
        error: {
            error: string;
            onClose: () => void;
            overlay: "dark";
        };
    };
    statusBanner: {
        shouldShow: boolean;
        isBridging: boolean;
        bridgingStatus: string;
    };
    feeErrorBanner: {
        shouldShow: boolean;
        message: string | null;
    };
    bridgeProviderSelectorProps: {
        bridgeProvider: BridgeProvider;
        onProviderChange: (provider: BridgeProvider) => void;
    };
    chainSelectorProps: {
        sourceChain: string;
        targetChain: string;
        showSourceDropdown: boolean;
        showTargetDropdown: boolean;
        bridgeFees: any;
        bridgeProvider: string;
        feesLoading: boolean;
        availableSourceChains: string[];
        onSourceChainSelect: (chain: string) => void;
        onTargetChainSelect: (chain: string) => void;
        onSwap: () => void;
        onSourceDropdownToggle: () => void;
        onTargetDropdownToggle: () => void;
    };
    amountInputProps: {
        wei: string;
        gdValue: any;
        bridgeWeiAmount: string;
        setBridgeAmount: (amount: string) => void;
        minimumAmount: any;
        isValid: boolean;
        reason: any;
        balance: any;
        toggleState: boolean;
    };
    expectedOutputProps: {
        expectedToReceive: any;
        targetChain: string;
        balance: any;
    };
    actionButtonProps: {
        web3Action: () => Promise<void>;
        disabled: boolean;
        isLoading: boolean;
        text: string;
        supportedChains: number[];
        variant: "primary";
        size: "lg";
    };
    feeInformationProps: {
        sourceChain: string;
        targetChain: string;
        bridgeProvider: BridgeProvider;
        protocolFeePercent?: number;
        bridgeFees: any;
        feesLoading: boolean;
    };
    transactionHistoryProps: {
        realTransactionHistory: any[];
        historyLoading: boolean;
        historyRefreshing: boolean;
        historyErrorsByChain: Record<number, string>;
        explorerChainId?: number;
        explorerAddress?: string;
        onRefresh: () => void;
        onTxDetailsPress: (tx: any) => void;
    };
}
export declare const useMPBBridgeViewController: ({ useCanMPBBridge, originChain, targetChainState, inputTransaction, pendingTransaction, protocolFeePercent, limits, fees, bridgeStatus, bridgeFlow, onBridgeStart, onBridgeFailed, onBridgeSuccess, bridgeReadOnlyUrls, bridgeProvider: propBridgeProvider, onBridgeProviderChange }: MPBBridgeProps) => MPBBridgeViewModel;
//# sourceMappingURL=useMPBBridgeViewController.d.ts.map