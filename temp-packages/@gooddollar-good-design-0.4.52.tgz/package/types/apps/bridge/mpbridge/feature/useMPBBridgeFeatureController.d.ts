import { MPBBridgeProps, MPBBridgeReadOnlyUrls } from "../types";
interface UseMPBBridgeFeatureControllerParams {
    onBridgeStart?: () => void;
    onBridgeSuccess?: () => void;
    onBridgeFailed?: (e: Error) => void;
    bridgeReadOnlyUrls?: MPBBridgeReadOnlyUrls;
}
export declare const useMPBBridgeFeatureController: ({ onBridgeStart, onBridgeSuccess, onBridgeFailed, bridgeReadOnlyUrls }: UseMPBBridgeFeatureControllerParams) => MPBBridgeProps;
export {};
//# sourceMappingURL=useMPBBridgeFeatureController.d.ts.map