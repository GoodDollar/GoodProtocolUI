import React from "react";
import type { MPBBridgeReadOnlyUrls } from "./types";
interface IMPBBridgeControllerProps {
    withHistory?: boolean;
    onBridgeStart?: () => void;
    onBridgeSuccess?: () => void;
    onBridgeFailed?: (e: Error) => void;
    bridgeReadOnlyUrls?: MPBBridgeReadOnlyUrls;
}
export declare const MPBBridgeController: React.FC<IMPBBridgeControllerProps>;
export {};
//# sourceMappingURL=MPBBridgeController.d.ts.map