import React from "react";
interface TransactionHistoryProps {
    realTransactionHistory: any[];
    historyLoading: boolean;
    historyRefreshing: boolean;
    historyErrorsByChain: Record<number, string>;
    explorerChainId?: number;
    explorerAddress?: string;
    onRefresh: () => void;
    onTxDetailsPress: (tx: any) => void;
}
export declare const TransactionHistory: React.FC<TransactionHistoryProps>;
export {};
//# sourceMappingURL=TransactionHistory.d.ts.map