import React from "react";
import { CurrencyValue } from "@usedapp/core";
interface ExpectedOutputProps {
    expectedToReceive: CurrencyValue;
    targetChain: string;
    balance: CurrencyValue;
}
export declare const ExpectedOutput: React.FC<ExpectedOutputProps>;
export {};
//# sourceMappingURL=ExpectedOutput.d.ts.map