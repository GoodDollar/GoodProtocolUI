import React from "react";
interface ChainSelectorProps {
    sourceChain: string;
    targetChain: string;
    showSourceDropdown: boolean;
    showTargetDropdown: boolean;
    bridgeFees: any;
    bridgeProvider: string;
    feesLoading: boolean;
    availableSourceChains: string[];
    onSourceChainSelect: (chain: string) => void;
    onTargetChainSelect: (chain: string) => void;
    onSwap: () => void;
    onSourceDropdownToggle: () => void;
    onTargetDropdownToggle: () => void;
}
export declare const ChainSelector: React.FC<ChainSelectorProps>;
export {};
//# sourceMappingURL=ChainSelector.d.ts.map