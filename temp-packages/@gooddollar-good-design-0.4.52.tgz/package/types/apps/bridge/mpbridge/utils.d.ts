type ChainName = "celo" | "fuse" | "mainnet" | "xdc";
type BridgeProvider = "axelar" | "layerzero";
export declare const getChainIcon: (chain: string) => string;
export declare const getChainColor: (chain: string) => string;
export declare const getChainLabel: (chain: string) => string;
export declare const getProviderSupportedPairs: (provider: BridgeProvider) => [ChainName, ChainName][];
export declare const getProviderSupportedSourceChains: (provider: BridgeProvider) => ChainName[];
export declare const isRouteSupportedByProvider: (source: string, target: string, provider: BridgeProvider) => boolean;
export declare const getValidTargetChains: (source: string, bridgeFees: any, bridgeProvider: string, feesLoading: boolean) => ChainName[];
export declare const CHAIN_ID_TO_NAME: Record<number, string>;
export declare const BRIDGE_SERVICE_MAPPING: {
    readonly 0: "axelar";
    readonly 1: "layerzero";
};
export declare const DEFAULT_BRIDGE_PROVIDER = "layerzero";
export declare const RECENT_TRANSACTION_THRESHOLD: number;
export declare const getChainName: (chainId: number) => string;
export declare const capitalizeChain: (chain: string) => string;
export declare const convertTransaction: (tx: any, currentChainId: number) => {
    chainId: number;
    network: string;
    displayName: string;
    contractName: string;
    contractAddress: any;
    account: any;
    type: string;
    isPool: boolean;
    date?: Date | undefined;
    id: any;
    transactionHash: any;
    sourceChain: string;
    targetChain: string;
    amount: any;
    bridgeProvider: string;
    status: string;
};
export {};
//# sourceMappingURL=utils.d.ts.map