import { FC } from "react";
interface IMicroBridgeControllerProps {
    withRelay?: boolean;
    withHistory?: boolean;
    onBridgeStart?: () => void;
    onBridgeSuccess?: () => void;
    onBridgeFailed?: (e: Error) => void;
}
export declare const MicroBridgeController: FC<IMicroBridgeControllerProps>;
export {};
//# sourceMappingURL=MicroBridgeController.d.ts.map