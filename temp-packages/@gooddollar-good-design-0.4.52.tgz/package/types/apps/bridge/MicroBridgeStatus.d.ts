import React from "react";
import { MicroBridgeProps } from "./types";
export declare const SingleTxStatus: ({ bridgeStatus, sourceChain, selfRelayStatus, relayStatus, handleFinish }: {
    bridgeStatus: any;
    sourceChain: any;
    selfRelayStatus: any;
    relayStatus: any;
    handleFinish: any;
}) => React.JSX.Element;
export declare const MicroBridgeStatus: ({ originChain, pendingTransaction, relayStatus, withRelay }: {
    bridgeStatus: MicroBridgeProps["bridgeStatus"];
    originChain: MicroBridgeProps["originChain"];
    pendingTransaction: MicroBridgeProps["pendingTransaction"];
    relayStatus: MicroBridgeProps["relayStatus"];
    withRelay: MicroBridgeProps["withRelay"];
}) => React.JSX.Element;
//# sourceMappingURL=MicroBridgeStatus.d.ts.map