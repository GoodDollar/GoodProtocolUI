import React from "react";
import { GeoLocation } from "@gooddollar/web3sdk-v2";
export type SegmentationProps = {
    onLocationRequest: (locationState: GeoLocation, account: string) => Promise<void>;
    onDone: (error?: Error | boolean) => Promise<void>;
    onDataPermission: (accepted: string) => Promise<void>;
    withNavBar: boolean;
    certificateSubjects: any;
    account: string;
    isWhitelisted?: boolean;
    expiryFormatted: string | undefined;
    isDev?: boolean;
    isWallet?: boolean;
};
export declare const SegmentationWizard: (props: SegmentationProps) => React.JSX.Element;
//# sourceMappingURL=SegmentationWizard.d.ts.map