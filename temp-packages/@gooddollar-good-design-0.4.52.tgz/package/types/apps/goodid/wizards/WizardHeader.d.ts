import React from "react";
export declare const WizardHeader: ({ onDone, withNavBar, error, onClose, stepHistory, onExit, ...props }: {
    onDone: (error?: Error) => Promise<void>;
    withNavBar: boolean;
    error: any;
    stepHistory?: number[] | undefined;
    onClose?: any;
    onExit?: (() => void) | undefined;
}) => React.JSX.Element;
//# sourceMappingURL=WizardHeader.d.ts.map