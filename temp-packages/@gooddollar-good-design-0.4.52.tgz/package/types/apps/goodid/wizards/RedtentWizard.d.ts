import React from "react";
import { RedTentProps } from "../types";
export declare const RedtentWizard: React.FC<RedTentProps>;
//# sourceMappingURL=RedtentWizard.d.ts.map