import { FC } from "react";
import { PoolCriteria } from "@gooddollar/web3sdk-v2";
export type UBIPoolOffer = PoolCriteria & {
    claimAmount?: string;
    claimDayFrequency?: string;
};
export interface CheckAvailableOffersProps {
    account: string;
    withNavBar: boolean;
    chainId: number;
    isDev?: boolean;
    onDone: (e?: Error | boolean | undefined) => Promise<void>;
    onError?: (e: Error | undefined) => void;
    onExit?: () => void;
}
declare const CheckAvailableOffers: FC<CheckAvailableOffersProps>;
export default CheckAvailableOffers;
//# sourceMappingURL=CheckAvailableOffers.d.ts.map