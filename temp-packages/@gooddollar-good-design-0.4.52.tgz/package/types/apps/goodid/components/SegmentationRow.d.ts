import React from "react";
import { CredentialSubject } from "@gooddollar/web3sdk-v2";
export declare const typeLabelsDispute: {
    Gender: {
        id: string;
        comment: string;
    };
    Age: {
        id: string;
        comment: string;
    };
    Location: {
        id: string;
        comment: string;
    };
};
export declare const typeLabelsSegmentation: {
    Gender: {
        id: string;
        comment: string;
    };
    Age: {
        id: string;
        comment: string;
    };
    Location: {
        id: string;
        comment: string;
    };
};
declare const SegmentationRow: ({ credentialSubject, typeName, onCheck }: {
    credentialSubject: CredentialSubject | undefined;
    typeName: keyof typeof typeLabelsSegmentation | keyof typeof typeLabelsDispute;
    onCheck?: ((checked: boolean) => void) | undefined;
}) => React.JSX.Element;
export default SegmentationRow;
//# sourceMappingURL=SegmentationRow.d.ts.map