export declare const CardRowItem: {
    baseStyle: {
        width: string;
        fontStyles: {
            subHeading: {
                fontFamily: string;
                fontWeight: number;
                color: string;
                fontSize: string;
            };
            subContent: {
                fontFamily: string;
                fontWeight: number;
                color: string;
                fontSize: string;
            };
        };
    };
};
export declare const GoodIdCard: {
    baseStyle: {
        width: string;
    };
};
//# sourceMappingURL=theme.d.ts.map