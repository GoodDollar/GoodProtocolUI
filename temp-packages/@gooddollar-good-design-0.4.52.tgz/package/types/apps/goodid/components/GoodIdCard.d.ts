import React from "react";
import { IStackProps } from "native-base";
import { CredentialSubjectsByType } from "@gooddollar/web3sdk-v2";
interface GoodIdCardProps extends IStackProps {
    account: string;
    isWhitelisted: boolean;
    certificateSubjects: CredentialSubjectsByType;
    avatar?: string;
    fullname?: string;
    expiryDate?: string;
    fontStyles?: any;
}
declare const GoodIdCard: React.FC<GoodIdCardProps>;
export default GoodIdCard;
//# sourceMappingURL=GoodIdCard.d.ts.map