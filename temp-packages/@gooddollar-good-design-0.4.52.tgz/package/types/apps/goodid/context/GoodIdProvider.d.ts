import { FC, PropsWithChildren } from "react";
interface GoodIdProviderProps {
    onGoToClaim?: () => void;
}
export declare const useGoodIdProvider: () => GoodIdProviderProps;
export declare const GoodIdProvider: FC<{
    onGoToClaim?: () => void;
} & PropsWithChildren>;
export {};
//# sourceMappingURL=GoodIdProvider.d.ts.map