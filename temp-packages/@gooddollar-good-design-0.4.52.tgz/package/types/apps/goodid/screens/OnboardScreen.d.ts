import React from "react";
import { IContainerProps } from "native-base";
import type { CredentialSubjectsByType } from "@gooddollar/web3sdk-v2";
export interface OnboardScreenProps {
    account: string;
    isPending: boolean;
    isWhitelisted?: boolean;
    certificateSubjects: CredentialSubjectsByType;
    expiryDate?: string;
    name?: string;
    onAccept: () => void;
    innerContainer?: any;
    fontStyles?: any;
}
export declare const OnboardScreen: React.FC<OnboardScreenProps & import("native-base/lib/typescript/components/primitives/Box").InterfaceBoxProps<IContainerProps> & {
    centerContent?: boolean | undefined;
} & {
    variant?: unknown;
    size?: unknown;
    colorScheme?: import("native-base/lib/typescript/components/types").ColorSchemeType;
}>;
//# sourceMappingURL=OnboardScreen.d.ts.map