import React from "react";
import type { InterfaceViewProps } from "native-base/lib/typescript/components/basic/View/types";
export declare const OffersAgreement: React.FC<InterfaceViewProps & {
    styles?: any;
    onDataPermission: (accepted: string) => Promise<void>;
}>;
//# sourceMappingURL=OffersAgreement.d.ts.map