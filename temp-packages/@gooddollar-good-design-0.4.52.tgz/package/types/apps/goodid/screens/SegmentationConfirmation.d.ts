import React from "react";
import { SegmentationProps } from "../wizards";
declare const SegmentationConfirmation: React.FC<import("native-base/lib/typescript/components/primitives/Stack/Stack").InterfaceStackProps & Partial<{}> & {
    variant?: unknown;
    size?: import("native-base/lib/typescript/components/types").ThemeComponentSizeType<"Stack">;
    colorScheme?: import("native-base/lib/typescript/components/types").ColorSchemeType;
} & Omit<SegmentationProps, "withNavBar" | "availableOffers" | "onDataPermission" | "onLocationRequest"> & {
    styles?: any;
    isWallet: boolean;
}>;
export default SegmentationConfirmation;
//# sourceMappingURL=SegmentationConfirmation.d.ts.map