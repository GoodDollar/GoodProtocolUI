import React from "react";
import { SegmentationProps } from "../wizards";
export declare const SegmentationScreen: ({ certificateSubjects }: {
    certificateSubjects: SegmentationProps["certificateSubjects"];
}) => React.JSX.Element;
//# sourceMappingURL=SegmentationScreen.d.ts.map