import React from "react";
export declare const GoodIdDetails: React.FC<{
    account: string;
    isVerified?: boolean | undefined;
    withHeader?: boolean | undefined;
    container?: any;
    header?: any;
    innerContainer?: any;
    section?: any;
}>;
//# sourceMappingURL=GoodIdDetails.d.ts.map