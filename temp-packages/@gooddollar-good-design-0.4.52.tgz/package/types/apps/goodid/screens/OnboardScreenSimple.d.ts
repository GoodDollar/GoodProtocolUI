import React from "react";
import { IContainerProps } from "native-base";
export interface OnboardScreenProps {
    isPending: boolean;
    isWhitelisted?: boolean;
    expiryDate?: string;
    onAccept: () => void;
    innerContainer?: any;
    fontStyles?: any;
}
export declare const OnboardScreenSimple: React.FC<OnboardScreenProps & import("native-base/lib/typescript/components/primitives/Box").InterfaceBoxProps<IContainerProps> & {
    centerContent?: boolean | undefined;
} & {
    variant?: unknown;
    size?: unknown;
    colorScheme?: import("native-base/lib/typescript/components/types").ColorSchemeType;
}>;
//# sourceMappingURL=OnboardScreenSimple.d.ts.map