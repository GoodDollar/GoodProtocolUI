import React from "react";
import { SegmentationProps } from "../wizards";
export declare const SegmentationDispute: React.FC<import("native-base/lib/typescript/components/primitives/Stack/Stack").InterfaceStackProps & Partial<{}> & {
    variant?: unknown;
    size?: import("native-base/lib/typescript/components/types").ThemeComponentSizeType<"Stack">;
    colorScheme?: import("native-base/lib/typescript/components/types").ColorSchemeType;
} & {
    certificateSubjects: SegmentationProps["certificateSubjects"];
    onDispute: (disputedValues: string[]) => Promise<void>;
    styles?: any;
}>;
//# sourceMappingURL=SegmentationDispute.d.ts.map