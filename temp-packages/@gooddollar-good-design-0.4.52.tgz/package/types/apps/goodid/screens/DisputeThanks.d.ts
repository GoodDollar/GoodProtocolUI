import React from "react";
export declare const DisputeThanks: () => React.JSX.Element;
//# sourceMappingURL=DisputeThanks.d.ts.map