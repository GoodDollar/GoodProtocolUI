declare const OnboardScreen: {
    baseStyle: {
        width: string;
        paddingX: number;
        alignItems: string;
        maxWidth: string;
        innerContainer: {
            space: number;
            width: number;
            justifyContent: string;
            alignItems: string;
        };
        fontStyles: {
            listLabel: {
                fontFamily: string;
                fontSize: string;
                color: string;
            };
            poweredBy: {
                underline: boolean;
                textAlign: string;
                fontSize: string;
                fontFamily: string;
                color: string;
            };
        };
    };
};
declare const OffersAgreement: {
    baseStyle: {
        paddingX: number;
        alignItems: string;
        styles: {
            buttonContainer: {
                width: string;
                space: number;
            };
            image: {
                width: number;
                height: number;
            };
        };
    };
};
declare const SegmentationConfirmation: {
    baseStyle: {
        display: string;
        flexDirection: string;
        alignItems: string;
        paddingX: number;
        paddingY: number;
    };
};
declare const SegmentationDispute: {
    baseStyle: {
        display: string;
        flexDirection: string;
        alignItems: string;
        paddingX: number;
        paddingY: number;
        styles: {
            buttonContainer: {
                width: string;
            };
        };
    };
};
declare const RedtentVideoInstructions: {
    baseStyle: {
        width: string;
        marginLeft: string;
        marginRight: string;
    };
};
declare const GoodIdDetails: {
    baseStyle: {
        container: {
            width: string;
            space: number;
            alignItems: string;
        };
        header: {
            width: string;
            space: number;
        };
        innerContainer: {
            space: number;
            alignItems: string;
            justifyContent: string;
            marginLeft: string;
            marginRight: string;
            width: string;
        };
        section: {
            flexShrink: number;
            backgroundColor: string;
            space: number;
            justifyContent: string;
            padding: string;
        };
    };
};
export { GoodIdDetails, OffersAgreement, OnboardScreen, RedtentVideoInstructions, SegmentationConfirmation, SegmentationDispute };
//# sourceMappingURL=theme.d.ts.map