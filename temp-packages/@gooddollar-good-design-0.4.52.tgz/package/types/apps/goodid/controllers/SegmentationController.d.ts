import React from "react";
import { AggregatedCertificate } from "@gooddollar/web3sdk-v2";
import { SegmentationProps } from "../wizards/SegmentationWizard";
export declare const SegmentationController: ({ account, certificates, certificateSubjects, expiryFormatted, fvSig, isWhitelisted, withNavBar, isDev, isWallet, onDone }: Omit<SegmentationProps, "availableOffers" | "onDataPermission" | "onLocationRequest"> & {
    fvSig?: string | undefined;
    certificates: AggregatedCertificate[];
}) => React.JSX.Element;
//# sourceMappingURL=SegmentationController.d.ts.map