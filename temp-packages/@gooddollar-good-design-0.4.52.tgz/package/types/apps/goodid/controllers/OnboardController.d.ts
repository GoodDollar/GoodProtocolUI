import React from "react";
import { IContainerProps } from "native-base";
import { OnboardScreenProps } from "../screens/OnboardScreenSimple";
export interface OnboardControllerProps {
    account: string;
    withNavBar: boolean;
    name?: string | undefined;
    fvSig?: string;
    isDev?: boolean;
    isWallet?: boolean;
    onFV?: () => void;
    onSkip: () => void;
    onDone: (e?: any) => Promise<void>;
    onExit: () => void;
}
export declare const OnboardController: (props: Pick<OnboardScreenProps, "innerContainer" | "fontStyles"> & OnboardControllerProps & IContainerProps) => React.JSX.Element;
//# sourceMappingURL=OnboardController.d.ts.map