import React from "react";
import { RedTentProps } from "../types";
export declare const RedtentController: (props: Omit<RedTentProps, "onVideo"> & {
    account: string;
}) => React.JSX.Element;
//# sourceMappingURL=RedtentController.d.ts.map