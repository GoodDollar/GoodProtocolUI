import { FC } from "react";
import { CheckAvailableOffersProps } from "../../goodid";
export declare const ClaimWizard: FC<Omit<CheckAvailableOffersProps, "onDone">>;
//# sourceMappingURL=ClaimWizard.d.ts.map