import { FC } from "react";
export declare const StartClaim: FC<{
    connectedAccount: string;
}>;
//# sourceMappingURL=StartClaim.d.ts.map