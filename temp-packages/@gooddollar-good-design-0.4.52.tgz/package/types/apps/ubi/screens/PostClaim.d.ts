import { FC } from "react";
export declare const PostClaim: FC;
//# sourceMappingURL=PostClaim.d.ts.map