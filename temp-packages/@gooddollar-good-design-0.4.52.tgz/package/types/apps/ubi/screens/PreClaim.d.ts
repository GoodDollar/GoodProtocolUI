import { FC } from "react";
export declare const PreClaim: FC;
//# sourceMappingURL=PreClaim.d.ts.map