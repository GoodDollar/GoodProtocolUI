import { FC, PropsWithChildren } from "react";
import { INewsFeedProvider, SupportedChains } from "@gooddollar/web3sdk-v2";
import { ClaimContextProps } from "../types";
export declare const useClaimContext: () => ClaimContextProps;
interface ClaimProviderProps {
    activePoolAddresses?: {
        [key: string]: string;
    };
    explorerEndPoints: {
        [key in keyof typeof SupportedChains]: string;
    };
    supportedChains?: SupportedChains[];
    withSignModals: boolean;
    provider?: any;
    onNews: () => void;
    onUpgrade: () => void;
    onConnect?: () => Promise<boolean>;
    onSuccess?: () => Promise<void>;
    onSendTx?: () => void;
    onSwitchChain?: (chainId: number) => Promise<void>;
    withNewsFeed: boolean;
    newsProps: Omit<INewsFeedProvider, "children">;
}
export declare const ClaimProvider: FC<PropsWithChildren<ClaimProviderProps>>;
export {};
//# sourceMappingURL=ClaimContext.d.ts.map