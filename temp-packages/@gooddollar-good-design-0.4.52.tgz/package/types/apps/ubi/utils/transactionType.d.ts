import { Transaction, ReceiveTransaction, SendTransaction } from "../types";
export declare const isReceiveTransaction: (transaction: Transaction) => transaction is ReceiveTransaction;
export declare const isSendTransaction: (transaction: Transaction) => transaction is SendTransaction;
export declare const isTxReject: (errorMessage: string) => boolean;
//# sourceMappingURL=transactionType.d.ts.map