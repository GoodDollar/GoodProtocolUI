import type { PoolDetails } from "@gooddollar/web3sdk-v2";
export declare const getUnclaimedPools: (pools: PoolDetails[] | undefined) => PoolDetails[] | undefined;
//# sourceMappingURL=pools.d.ts.map