import React from "react";
import { ClaimContextProps, Transaction } from "../types";
export type TransactionCardProps = {
    transaction: Transaction;
    onTxDetailsPress: ClaimContextProps["onTxDetailsPress"];
};
export declare const TransactionCard: React.FC<TransactionCardProps>;
type TransactionListProps = {
    transactions: Transaction[] | undefined;
    onTxDetailsPress: ClaimContextProps["onTxDetailsPress"];
    limit?: number;
};
export declare const TransactionList: ({ transactions, onTxDetailsPress, limit }: TransactionListProps) => React.JSX.Element;
export {};
//# sourceMappingURL=TransactionStateCard.d.ts.map