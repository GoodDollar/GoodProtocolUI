import React from "react";
import { EnvKey } from "@gooddollar/web3sdk-v2";
interface IGdOnramperProps {
    isTesting?: boolean;
    env?: EnvKey;
    onEvents: (action: string, data?: any, error?: string) => void;
    selfSwap?: boolean;
    withSwap?: boolean;
    donateOrExecTo?: string;
    callData?: string;
    apiKey?: string;
}
export declare const GdOnramperWidget: ({ isTesting, env, onEvents, selfSwap, withSwap, donateOrExecTo, callData, apiKey }: IGdOnramperProps) => React.JSX.Element;
export {};
//# sourceMappingURL=GdOnramperWidget.d.ts.map