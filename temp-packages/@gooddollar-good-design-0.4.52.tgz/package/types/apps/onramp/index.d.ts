export * from "./Onramper";
export * from "./GdOnramperWidget";
//# sourceMappingURL=index.d.ts.map