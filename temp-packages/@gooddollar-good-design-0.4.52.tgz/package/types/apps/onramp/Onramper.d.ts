import React from "react";
import { WebViewMessageEvent } from "react-native-webview";
export type OnramperCallback = (event: WebViewMessageEvent) => void;
type WidgetParams = Record<string, string | number | boolean | undefined>;
export declare const Onramper: ({ onEvent, onGdEvent, step, setStep, isTesting, apiKey, urlSignature, onUrlSignContentReady, widgetParams, targetNetwork, targetWallet }: {
    onEvent?: OnramperCallback | undefined;
    onGdEvent: (action: string) => void;
    step: number;
    setStep: (step: number) => void;
    isTesting: boolean;
    widgetParams?: WidgetParams | undefined;
    targetWallet?: string | undefined;
    targetNetwork?: string | undefined;
    apiKey?: string | undefined;
    urlSignature?: string | undefined;
    onUrlSignContentReady?: ((signContent: string) => void) | undefined;
}) => React.JSX.Element;
export {};
//# sourceMappingURL=Onramper.d.ts.map