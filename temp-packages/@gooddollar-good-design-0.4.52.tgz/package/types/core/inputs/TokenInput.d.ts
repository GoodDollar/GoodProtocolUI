import React from "react";
import { CurrencyValue } from "@usedapp/core";
export declare const TokenInput: ({ balanceWei, gdValue, onChange, toggleState, _numericformat, _button, minAmountWei, inputDebounceMs, ...props }: {
    balanceWei: string;
    onChange: (v: string) => void;
    gdValue: CurrencyValue;
    toggleState?: any;
    _numericformat?: any;
    _button?: any;
    _text?: any;
    minAmountWei?: string | undefined;
    inputDebounceMs?: number | undefined;
}) => React.JSX.Element;
//# sourceMappingURL=TokenInput.d.ts.map