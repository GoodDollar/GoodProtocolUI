import { StyledProps } from "native-base";
import React from "react";
export declare const isAddressValid: (v: string) => boolean;
export declare const AddressInput: ({ address, onChange, ...props }: {
    address?: string | undefined;
    onChange: (v: string) => void;
} & StyledProps) => React.JSX.Element;
//# sourceMappingURL=AddressInput.d.ts.map