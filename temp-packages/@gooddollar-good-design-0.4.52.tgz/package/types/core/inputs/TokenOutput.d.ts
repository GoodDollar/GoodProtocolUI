import React from "react";
import { CurrencyValue } from "@usedapp/core";
export declare const TokenOutput: ({ outputValue, _numericformat, ...props }: {
    outputValue: CurrencyValue;
    _numericformat?: any;
    _button?: any;
    _text?: any;
}) => React.JSX.Element;
//# sourceMappingURL=TokenOutput.d.ts.map