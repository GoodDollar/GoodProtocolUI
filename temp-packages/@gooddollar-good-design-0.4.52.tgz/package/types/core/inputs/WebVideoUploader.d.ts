import React from "react";
type Props = {
    onDone: (video?: {
        base64: string;
        extension: string;
    }, error?: Error) => Promise<void>;
};
export declare const WebVideoUploader: ({ onUpload, isLoading }: {
    onUpload: Props["onDone"];
    isLoading: boolean;
}) => React.JSX.Element;
export {};
//# sourceMappingURL=WebVideoUploader.d.ts.map