import React from "react";
import { IButtonProps, ITextProps, IHeadingProps } from "native-base";
export declare const TransText: ({ t, values, comment, ...props }: {
    t: string;
    values?: any;
    comment?: string | undefined;
} & import("native-base/lib/typescript/components/primitives/Text/types").InterfaceTextProps<ITextProps> & {
    variant?: unknown;
    size?: unknown;
    colorScheme?: import("native-base/lib/typescript/components/types").ColorSchemeType;
}) => React.JSX.Element;
export declare const TransHeading: ({ t, ...props }: {
    t: string;
} & import("native-base/lib/typescript/components/primitives/Heading/types").IterfaceHeadingProps & Partial<{}> & {
    variant?: unknown;
    size?: import("native-base/lib/typescript/components/types").ThemeComponentSizeType<"Heading">;
    colorScheme?: import("native-base/lib/typescript/components/types").ColorSchemeType;
}) => React.JSX.Element;
export declare const TransTitle: ({ t, values, ...props }: {
    t: string;
    values?: any;
} & import("native-base/lib/typescript/components/primitives/Text/types").InterfaceTextProps<ITextProps> & {
    variant?: unknown;
    size?: unknown;
    colorScheme?: import("native-base/lib/typescript/components/types").ColorSchemeType;
}) => React.JSX.Element;
export declare const TransButton: ({ t, ...props }: {
    t: string;
} & import("native-base/lib/typescript/components/primitives/Button/types").InterfaceButtonProps & Partial<{}> & {
    variant?: import("native-base/lib/typescript/components/types").ResponsiveValue<"link" | "ghost" | "outline" | "solid" | "subtle" | "unstyled" | (string & {})>;
    size?: import("native-base/lib/typescript/components/types").ThemeComponentSizeType<"Button">;
    colorScheme?: import("native-base/lib/typescript/components/types").ColorSchemeType;
}) => React.JSX.Element;
//# sourceMappingURL=Trans.d.ts.map