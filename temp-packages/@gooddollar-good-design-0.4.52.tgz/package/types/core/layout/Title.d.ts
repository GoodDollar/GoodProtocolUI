import { ITextProps } from "native-base";
import { FC } from "react";
declare const Title: FC<ITextProps>;
export declare const theme: {
    defaultProps: {
        color: string;
        size: string;
    };
    baseStyle: {
        fontFamily: string;
        fontWeight: string;
        lineHeight: number | undefined;
    };
    sizes: {
        lg: {
            fontSize: string;
        };
    };
    variants: {
        "subtitle-grey": () => {
            fontFamily: string;
            fontSize: string;
            fontWeight: string;
            color: string;
            lineHeight: string | undefined;
        };
        "title-gdblue": () => {
            color: string;
            fontWeight: number;
            fontFamily: string;
            fontSize: string;
            textAlign: string;
            lineHeight: number | undefined;
            margin: string | undefined;
        };
        "title-gdred": () => {
            color: string;
            fontWeight: number;
            fontFamily: string;
            fontSize: string;
            textAlign: string;
            lineHeight: number | undefined;
        };
    };
};
export default Title;
//# sourceMappingURL=Title.d.ts.map