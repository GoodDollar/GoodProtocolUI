import React, { FC } from "react";
import { ITextProps } from "native-base";
import { CurrencyValue, QueryParams } from "@usedapp/core";
interface BalanceGDProps {
    gdPrice?: number;
    refresh?: QueryParams["refresh"];
    requiredChainId?: number;
    showUsd: boolean | undefined;
}
declare const BalanceGD: FC<BalanceGDProps>;
export declare const GdAmount: ({ amount, withDefaultSuffix, withFullBalance, ...props }: {
    amount: CurrencyValue;
    withDefaultSuffix: boolean;
    withFullBalance?: boolean | undefined;
    color?: any;
    options?: any;
} & import("native-base/lib/typescript/components/primitives/Text/types").InterfaceTextProps<ITextProps> & {
    variant?: unknown;
    size?: unknown;
    colorScheme?: import("native-base/lib/typescript/components/types").ColorSchemeType;
}) => React.JSX.Element;
export default BalanceGD;
//# sourceMappingURL=BalanceGD.d.ts.map