import React from "react";
declare const BlueBullet: () => React.JSX.Element;
declare const BulletPointList: ({ bulletPoints }: {
    bulletPoints: string[];
}) => React.JSX.Element;
export { BlueBullet, BulletPointList };
//# sourceMappingURL=BulletPoint.d.ts.map