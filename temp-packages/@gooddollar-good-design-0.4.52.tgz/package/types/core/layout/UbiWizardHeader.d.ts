import { FC, PropsWithChildren } from "react";
import { RedTentProps } from "../../apps/goodid/types";
export declare const UbiWizardHeader: FC<PropsWithChildren<{
    onDone: RedTentProps["onDone"];
    onExit: () => void;
    withNavBar: boolean;
}>>;
//# sourceMappingURL=UbiWizardHeader.d.ts.map