import React from "react";
interface ISlideDownTabProps {
    tabTitle: string;
    arrowSmall?: boolean;
    styles?: {
        container?: any;
        button?: any;
        content?: any;
        innerButton?: any;
        titleFont?: any;
    };
    children: React.ReactNode;
    [key: string]: any;
}
declare const SlideDownTab: ({ tabTitle, styles, children, ...props }: ISlideDownTabProps) => React.JSX.Element;
export default SlideDownTab;
//# sourceMappingURL=SlideDownTab.d.ts.map