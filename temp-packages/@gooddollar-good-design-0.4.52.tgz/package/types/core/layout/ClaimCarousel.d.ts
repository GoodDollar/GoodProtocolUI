import { FC } from "react";
import { IClaimCard } from "../buttons";
interface ClaimCarouselProps {
    cards: Array<IClaimCard>;
    isMobile: boolean;
    claimed?: boolean;
}
declare const ClaimCarousel: FC<ClaimCarouselProps>;
export default ClaimCarousel;
//# sourceMappingURL=ClaimCarousel.d.ts.map