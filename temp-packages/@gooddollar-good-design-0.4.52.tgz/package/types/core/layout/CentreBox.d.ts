import { FC } from "react";
import { IBoxProps } from "native-base/lib/typescript/components/primitives/Box";
export declare const theme: {
    baseStyle: {
        display: string;
        justifyContent: string;
        alignItems: string;
    };
};
export declare const CentreBox: FC<IBoxProps>;
export default CentreBox;
//# sourceMappingURL=CentreBox.d.ts.map