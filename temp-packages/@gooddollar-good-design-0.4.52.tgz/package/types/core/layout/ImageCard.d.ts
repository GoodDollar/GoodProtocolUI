import React from "react";
import { ICenterProps } from "native-base";
interface IImageCard extends ICenterProps {
    picture?: any;
    title: string;
    content: object;
    link: string;
    footer?: object;
    styles?: {
        button?: object;
        container?: object;
        title?: object;
        content?: object;
        picture?: object;
        footer?: object;
    };
}
export declare const theme: {
    baseStyle: {
        display: string;
        overflow: string;
        marginBottom: number;
        paddingBottom: number;
        styles: {
            footer: {
                marginTop: number;
                display: string;
                width: string;
                alignItems: string;
            };
            picture: {
                minWidth: string;
                width: string;
                paddingBottom: string;
            };
        };
    };
    variants: {
        "offer-card": () => {
            borderRadius: number;
            styles: {
                button: {
                    marginBottom: number;
                };
                content: {
                    paddingY: number;
                    paddingX: number;
                    width: string;
                    alignItems: string;
                };
                picture: {
                    resizeMode: string;
                } | {
                    resizeMode: string;
                    minWidth: string;
                    width: string;
                    paddingBottom: string;
                    maxWidth?: undefined;
                    height?: undefined;
                    aspectRatio?: undefined;
                } | {
                    resizeMode: string;
                    maxWidth: string;
                    height: string;
                    aspectRatio: number;
                    minWidth?: undefined;
                    width?: undefined;
                    paddingBottom?: undefined;
                };
                title: {
                    fontFamily: string;
                    fontSize: string;
                    fontWeight: number;
                    color: string;
                    paddingBottom: number;
                };
            };
        };
        "news-card": () => {
            borderLeftWidth: number;
            borderLeftColor: string;
            borderRadius: number;
            styles: {
                footer: {
                    display: string;
                    width: string;
                    alignItems: string;
                };
                container: {
                    flexDirection: string;
                    height: string;
                    justifyContent: string;
                };
                button: {
                    width: string;
                    height: string;
                    marginBottom: number;
                };
                content: {
                    flex: number;
                    justifyContent: string;
                    color: string;
                    fontFamily: string;
                    fontSize: string;
                    fontWeight: string;
                    lineHeight: number;
                    paddingBottom: number;
                    maxWidth: number;
                    paddingTop: number;
                    paddingX: number;
                };
                picture: {
                    resizeMode: string;
                    width: string;
                } | {
                    resizeMode: string;
                    paddingBottom: string;
                    aspectRatio?: undefined;
                    width: string;
                } | {
                    resizeMode: string;
                    aspectRatio: number;
                    paddingBottom?: undefined;
                    width: string;
                };
                title: {
                    fontFamily: string;
                    fontSize: string;
                    fontWeight: number;
                    lineHeight: number | undefined;
                    color: string;
                    paddingBottom: number;
                };
            };
        };
    };
};
declare const ImageCard: React.FC<IImageCard>;
export default ImageCard;
//# sourceMappingURL=ImageCard.d.ts.map