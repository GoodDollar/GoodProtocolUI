import React from "react";
interface ActionHeaderProps {
    textColor: any;
    actionText: string;
}
declare const ActionHeader: React.MemoExoticComponent<({ textColor, actionText }: ActionHeaderProps) => React.JSX.Element>;
export default ActionHeader;
//# sourceMappingURL=ActionHeader.d.ts.map