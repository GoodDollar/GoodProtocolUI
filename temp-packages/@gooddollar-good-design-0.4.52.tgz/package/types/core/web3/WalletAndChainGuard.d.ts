import React from "react";
export declare const WalletAndChainGuard: ({ validChains, children }: {
    connectWallet?: (() => void) | undefined;
    switchChain?: (() => void) | undefined;
    validChains?: number[] | undefined;
    children: any;
}) => React.JSX.Element;
//# sourceMappingURL=WalletAndChainGuard.d.ts.map