import React from "react";
interface RedirectModalProps {
    open: boolean;
    url: string;
    onClose: () => void;
}
export declare const RedirectModal: ({ open, url, onClose, ...props }: RedirectModalProps) => React.JSX.Element;
export {};
//# sourceMappingURL=RedirectModal.d.ts.map