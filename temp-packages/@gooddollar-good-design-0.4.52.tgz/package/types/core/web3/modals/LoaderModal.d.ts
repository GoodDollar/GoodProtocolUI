import React from "react";
export declare const LoaderModal: ({ title, overlay, loading, onClose }: {
    title: string;
    overlay: "dark" | "blur";
    loading: boolean;
    onClose: () => void;
}) => React.JSX.Element;
//# sourceMappingURL=LoaderModal.d.ts.map