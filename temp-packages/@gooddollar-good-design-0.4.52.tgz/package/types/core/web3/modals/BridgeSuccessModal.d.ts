import React from "react";
export declare const BridgeSuccessContent: () => React.JSX.Element;
export declare const BridgeSuccessModal: ({ open, onClose, ...props }: {
    open: boolean;
    onClose?: (() => void) | undefined;
}) => React.JSX.Element;
//# sourceMappingURL=BridgeSuccessModal.d.ts.map