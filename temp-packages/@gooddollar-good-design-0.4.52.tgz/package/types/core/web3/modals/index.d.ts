export { default as BasicStyledModal } from "./BasicStyledModal";
export * from "./BasicStyledModal";
export * from "./RedirectModal";
export * from "./ClaimSuccessModal";
export * from "./VerifyUniqueModal";
export * from "./TxModal";
export * from "./LoaderModal";
export * from "./ErrorModal";
export * from "./YouSureModal";
export * from "./TxDetailsModal";
export * from "./SwitchChainModal";
//# sourceMappingURL=index.d.ts.map