import React from "react";
export interface BasicModalProps {
    show: boolean;
    onClose: () => void;
    withOverlay?: "blur" | "dark";
    withCloseButton: boolean;
    title: any;
    modalStyle?: any;
    headerStyle?: any;
    titleVariant?: string;
    bodyStyle?: any;
    footerStyle?: any;
    body?: JSX.Element;
    footer?: JSX.Element;
}
interface CtaOrLearnModalProps extends BasicModalProps {
    type: "cta" | "ctaX" | "learn" | "social";
    loading?: never;
}
interface AltModalProps extends BasicModalProps {
    type: "loader";
    loading: boolean;
}
export type StyledModalProps = CtaOrLearnModalProps | AltModalProps;
export declare const ModalLoaderBody: () => React.JSX.Element;
export declare const ModalErrorBody: ({ error }: {
    error: string;
}) => React.JSX.Element;
export declare const ModalFooterCta: ({ buttonText, dontShowAgainKey, action, dontShowAgainCopy, styleProps }: {
    buttonText: string;
    dontShowAgainKey?: string | undefined;
    styleProps?: any;
    dontShowAgainCopy?: string | undefined;
    action: () => void;
}) => React.JSX.Element;
export declare const ModalFooterCtaX: ({ extUrl, buttonText }: {
    extUrl: string;
    buttonText: string;
}) => React.JSX.Element;
export declare const ModalFooterSocial: ({ message, url }?: {
    message?: string | undefined;
    url?: string | undefined;
}) => React.JSX.Element;
declare const BasicStyledModal: React.FC<StyledModalProps>;
export default BasicStyledModal;
//# sourceMappingURL=BasicStyledModal.d.ts.map