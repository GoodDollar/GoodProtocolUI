import { FC, PropsWithChildren } from "react";
export declare const SwitchChainModal: FC<PropsWithChildren>;
//# sourceMappingURL=SwitchChainModal.d.ts.map