export declare const BasicStyledModal: {
    baseStyle: {
        headerStyle: {
            padding: number;
        };
        bodyStyle: {
            padding: number;
            textAlign: string;
        };
        footerStyle: {
            justifyContent: string;
        };
    };
};
//# sourceMappingURL=BasicModal.theme.d.ts.map