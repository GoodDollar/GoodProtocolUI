import React from "react";
export interface ClaimSuccessModalProps {
    open: boolean;
    onClose?: () => void;
    isFirstTimeClaimer?: boolean;
    socialShareMessage?: string;
    socialShareUrl?: string;
}
export declare const ClaimSuccessModal: ({ open, onClose, isFirstTimeClaimer, socialShareMessage, socialShareUrl, ...props }: ClaimSuccessModalProps) => React.JSX.Element;
//# sourceMappingURL=ClaimSuccessModal.d.ts.map