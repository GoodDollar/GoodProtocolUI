import React, { FC } from "react";
import { TransactionStatus } from "@usedapp/core";
interface ITxModalProps {
    type: "send" | "sign" | "signMultiClaim" | "identity" | "goodid";
    isPending: boolean;
    customTitle?: {
        title: {
            id: string;
            values: any;
        };
    };
    onClose?: () => void;
    title?: string;
    content?: string;
}
export declare const TxModal: FC<ITxModalProps>;
export declare const TxModalStatus: ({ txStatus, onClose }: {
    txStatus: TransactionStatus | Partial<TransactionStatus>;
    onClose: () => void;
}) => React.JSX.Element | null;
export {};
//# sourceMappingURL=TxModal.d.ts.map