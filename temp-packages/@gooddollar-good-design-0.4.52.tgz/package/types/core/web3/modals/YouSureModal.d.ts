import React from "react";
declare const youSureContent: {
    deleteAccount: {
        title: string;
        content: string;
        buttonText: string;
    };
    offers: {
        title: string;
        content: string;
        buttonText: string;
    };
    transaction: {
        title: string;
        content: string;
        buttonText: string;
    };
};
interface YouSureModalProps {
    open: boolean;
    type: keyof typeof youSureContent;
    dontShowAgainKey?: string | undefined;
    styleProps?: any;
    action: () => void;
    onClose: () => void;
}
export declare const YouSureModal: ({ open, action, onClose, dontShowAgainKey, styleProps, ...props }: YouSureModalProps) => React.JSX.Element;
export {};
//# sourceMappingURL=YouSureModal.d.ts.map