export * from "./BasicModal.theme";
//# sourceMappingURL=theme.d.ts.map