import React from "react";
export declare const ErrorModal: ({ error, reason, overlay, onClose, ...props }: {
    error: string;
    reason?: string | undefined;
    overlay: "dark" | "blur";
    onClose: () => void;
}) => React.JSX.Element;
//# sourceMappingURL=ErrorModal.d.ts.map