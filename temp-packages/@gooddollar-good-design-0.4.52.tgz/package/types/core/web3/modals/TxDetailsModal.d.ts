import React from "react";
export declare const TxDetailsModal: ({ open, onClose, tx, ...props }: {
    open: boolean;
    onClose?: (() => void) | undefined;
    tx: any;
}) => React.JSX.Element;
//# sourceMappingURL=TxDetailsModal.d.ts.map