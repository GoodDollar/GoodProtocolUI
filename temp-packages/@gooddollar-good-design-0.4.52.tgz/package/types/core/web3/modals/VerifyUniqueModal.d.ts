import React from "react";
export declare const VerifyUniqueModal: ({ open, url, onClose, chainId, firstName, method, ...props }: any) => React.JSX.Element;
//# sourceMappingURL=VerifyUniqueModal.d.ts.map