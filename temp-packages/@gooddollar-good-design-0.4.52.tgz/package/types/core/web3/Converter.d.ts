import React from "react";
declare const Converter: React.MemoExoticComponent<({ gdPrice }: {
    gdPrice?: number | undefined;
}) => React.JSX.Element>;
export default Converter;
//# sourceMappingURL=Converter.d.ts.map