import React from "react";
export declare const ExplorerLink: ({ chainId, addressOrTx, text, fontStyle, isPool, ...props }: {
    chainId: number | undefined;
    addressOrTx: string | undefined;
    _icon?: any;
    text?: string | undefined;
    withIcon?: boolean | undefined;
    fontStyle?: {
        fontSize: string | number;
        fontFamily: string;
        fontWeight: string | number;
    } | undefined;
    maxWidth?: string | number | undefined;
    isPool?: boolean | undefined;
}) => React.JSX.Element | null;
//# sourceMappingURL=ExplorerLink.d.ts.map