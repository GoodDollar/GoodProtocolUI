import SvgXml from "react-inlinesvg";
export default SvgXml;
//# sourceMappingURL=SvgXml.web.d.ts.map