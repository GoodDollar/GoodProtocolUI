export { default as Image } from "./Image";
export { default as SvgXml } from "./SvgXml.web";
//# sourceMappingURL=index.d.ts.map