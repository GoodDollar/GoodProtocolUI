import { FC } from "react";
import { IImageProps } from "native-base";
declare const Image: FC<IImageProps>;
export default Image;
//# sourceMappingURL=Image.d.ts.map