export { SvgXml as default } from "react-native-svg";
//# sourceMappingURL=SvgXml.native.d.ts.map