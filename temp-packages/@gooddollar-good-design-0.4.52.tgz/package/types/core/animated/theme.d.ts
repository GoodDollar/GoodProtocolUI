export { theme as AnimatedProgress } from "./AnimatedProgress";
//# sourceMappingURL=theme.d.ts.map