import React from "react";
declare const SpinnerCheckMark: () => React.JSX.Element;
export default SpinnerCheckMark;
//# sourceMappingURL=SpinnerCheckMark.d.ts.map