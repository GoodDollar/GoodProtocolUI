import React from "react";
interface IAnimatedProps {
    containerStyles?: object;
    progressStyles?: object;
    progressBar?: object;
    value: number;
    animationDuration?: number;
}
export declare const theme: {
    baseStyle: {
        containerStyles: {
            flex: number;
            alignItems: string;
            justifyContent: string;
            width: string;
        };
        progressStyles: {
            width: string;
            height: number;
            backgroundColor: string;
            borderRadius: number;
            overflow: string;
        };
        progressBar: {
            height: string;
            backgroundColor: string;
        };
    };
};
declare const AnimatedProgress: React.FC<IAnimatedProps>;
export default AnimatedProgress;
//# sourceMappingURL=AnimatedProgress.d.ts.map