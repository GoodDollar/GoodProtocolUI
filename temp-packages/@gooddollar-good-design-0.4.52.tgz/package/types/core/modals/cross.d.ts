import React from "react";
declare const CrossIcon: () => React.JSX.Element;
export default CrossIcon;
//# sourceMappingURL=cross.d.ts.map