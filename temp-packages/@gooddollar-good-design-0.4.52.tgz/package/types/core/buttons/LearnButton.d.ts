import React from "react";
import { linksNew } from "../constants";
type LearnButtonType = {
    icon?: any;
    label?: string;
    link?: string;
    type: keyof typeof linksNew;
};
declare const LearnButton: ({ type }: LearnButtonType) => React.JSX.Element;
export default LearnButton;
//# sourceMappingURL=LearnButton.d.ts.map