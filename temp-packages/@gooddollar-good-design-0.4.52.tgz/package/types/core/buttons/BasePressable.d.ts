import { ITextProps, StyledProps, IPressableProps } from "native-base";
import { IViewProps } from "native-base/lib/typescript/components/basic/View/types";
import React from "react";
type InteractionStyles = {
    [Property in keyof StyledProps]: any;
};
type interactionEvents = "focus" | "hover" | "pressed";
type InterProps = {
    [key in interactionEvents]?: InteractionStyles;
};
export interface BasePressableProps extends IPressableProps {
    text?: string;
    onPress?: () => void;
    innerText?: ITextProps;
    textInteraction?: InterProps;
    viewInteraction?: InterProps;
    innerView?: IViewProps;
    children?: any;
    name?: string;
}
declare const BasePressable: React.FC<BasePressableProps>;
export declare const theme: {
    defaultProps: {};
    variants: {
        arrowIcon: () => {
            bgColor: string;
            w: string;
            h: number;
            shadow: string;
            innerText: {
                fontSize: string;
                fontWeight: string;
                fontFamily: string;
                color: string;
                pt: string;
                pb: number;
            };
            innerView: {
                width: string;
                flexDirection: string;
                justifyContent: string;
                alignItems: string;
                pt: string;
                pl: number;
                pr: number;
                pb: number;
                flexGrow: number;
            };
            borderRadius: string;
            _hover: {
                bgColor: string;
            };
        };
        externalLink: () => {
            innerView: {
                h: string;
                bgColor: string;
                display: string;
                flexDir: string;
                alignItems: string;
                justifyContent: string;
                style: {
                    flexGrow: number;
                };
            };
            viewInteraction: {
                hover: {
                    bgColor: string;
                };
            };
        };
    };
};
export default BasePressable;
//# sourceMappingURL=BasePressable.d.ts.map