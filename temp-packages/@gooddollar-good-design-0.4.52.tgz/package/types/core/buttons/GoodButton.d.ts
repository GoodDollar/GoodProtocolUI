import React from "react";
declare const GoodButton: React.FC<import("native-base/lib/typescript/components/primitives/Button/types").InterfaceButtonProps & Partial<{}> & {
    variant?: import("native-base/lib/typescript/components/types").ResponsiveValue<"link" | "ghost" | "outline" | "solid" | "subtle" | "unstyled" | (string & {})>;
    size?: import("native-base/lib/typescript/components/types").ThemeComponentSizeType<"Button">;
    colorScheme?: import("native-base/lib/typescript/components/types").ColorSchemeType;
}>;
export declare const theme: {
    baseStyle: (baseTools: {
        colorMode: string;
    }) => any;
    variants: {
        "link-like": () => {
            _text: {
                color: string;
                underline: boolean;
                textTransform: string;
                fontFamily: string;
                fontSize: string;
                fontWeight: string;
            };
            _hover: {
                backgroundColor: string;
            };
            backgroundColor: string | undefined;
            paddingY: number;
            paddingX: number;
            textAlign: string;
            lineHeight: number;
        };
        outlined: () => {};
    };
};
export default GoodButton;
//# sourceMappingURL=GoodButton.d.ts.map