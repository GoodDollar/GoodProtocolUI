import React from "react";
export declare const LinkButton: React.FC<{
    buttonText: string;
    url?: string | undefined;
    onPress?: (() => void) | undefined;
}>;
//# sourceMappingURL=StyledLinkButton.d.ts.map