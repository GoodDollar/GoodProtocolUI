import React from "react";
declare const SocialsLink: React.FC<{
    network: string;
    logo: string;
    url: string;
}>;
export declare const SocialShareBar: React.ExoticComponent<{
    children?: React.ReactNode;
}>;
export default SocialsLink;
//# sourceMappingURL=SocialLink.d.ts.map