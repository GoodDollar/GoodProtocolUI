export declare const theme: {
    variants: {
        "styled-blue": () => {
            _web: {
                cursor: string;
            };
            _stack: {
                _web: {
                    cursor: string;
                };
            };
            _disabled: {
                _web: {
                    cursor: string;
                };
                opacity: number;
            };
            _checked: {
                borderColor: string;
                bg: string;
                _hover: {
                    borderColor: string;
                    bg: string;
                    _disabled: {
                        borderColor: string;
                        bg: string;
                    };
                };
            };
        };
    };
};
//# sourceMappingURL=Checkbox.theme.d.ts.map