import React from "react";
export declare const CtaButton: ({ text, onPress }: {
    text: string;
    onPress: () => void;
}) => React.JSX.Element;
//# sourceMappingURL=CtaButton.d.ts.map