import { IButtonProps, ITextProps } from "native-base";
import { IViewProps } from "native-base/lib/typescript/components/basic/View/types";
import React from "react";
export interface BaseButtonProps extends IButtonProps {
    text: string;
    onPress?: () => void;
    innerText?: ITextProps;
    innerView?: IViewProps;
    children?: any;
    name?: string;
}
declare const BaseButton: React.FC<BaseButtonProps>;
export declare const theme: {
    defaultProps: {};
    baseStyle: () => {
        maxWidth: number;
        backgroundColor: string;
        _hover: {
            bg: string;
        };
        innerText: {
            fontWeight: string;
            color: string;
            textAlign: string;
        };
    };
    variants: {
        "standard-blue": () => {
            innerView: {
                backgroundColor: string;
                borderRadius: number;
                width: number;
                textAlign: string;
            };
            innerText: {
                fontFamily: string;
                fontSize: string;
                fontWeight: string;
                textTransform: string;
            };
        };
        "link-like": () => {
            innerView: {
                backgroundColor: string;
                paddingY: number;
                paddingX: number;
                width: number;
                textAlign: string;
            };
            innerText: {
                fontFamily: string;
                fontSize: string;
                fontWeight: string;
                lineHeight: number;
                color: string;
                underline: boolean;
                textTransform: string;
            };
        };
    };
};
export default BaseButton;
//# sourceMappingURL=BaseButton.d.ts.map