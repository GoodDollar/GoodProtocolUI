import React from "react";
import { FVFlowProps } from "./types";
declare const ClaimButton: ({ firstName, method, refresh, claimed, claiming, claim, chainId, handleConnect, onEvent, redirectUrl, supportedChains, ...props }: FVFlowProps) => React.JSX.Element;
export default ClaimButton;
//# sourceMappingURL=ClaimButton.d.ts.map