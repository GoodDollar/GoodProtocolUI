import { FC } from "react";
import { BasePressableProps } from "./BasePressable";
declare const ArrowButton: FC<BasePressableProps>;
export default ArrowButton;
//# sourceMappingURL=ArrowButton.d.ts.map