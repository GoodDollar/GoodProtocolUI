export type learnSources = "send" | "bridging" | "network" | "sign" | "signMultiClaim" | "identity" | "goodid";
type links = {
    link: string;
    label: string;
    icon: any;
};
export declare const linksNew: Record<learnSources, links>;
export type sourceOrAlt = {
    source: learnSources;
};
export {};
//# sourceMappingURL=constants.d.ts.map