import { FC, PropsWithChildren } from "react";
import { NativeBaseProviderProps } from "native-base";
declare const GoodXProvider: FC<PropsWithChildren<{
    nativeBaseProps: NativeBaseProviderProps;
}>>;
export default GoodXProvider;
//# sourceMappingURL=GoodXProvider.d.ts.map