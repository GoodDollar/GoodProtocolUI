export { default as GoodXProvider } from "./GoodXProvider";
//# sourceMappingURL=index.d.ts.map