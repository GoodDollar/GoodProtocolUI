import { FC, PropsWithChildren } from "react";
declare const locali18n: import("@lingui/core").I18n;
export declare const useGoodUILanguage: () => {
    language: string;
    setLanguage: (lang: string) => void;
    ci18n: typeof locali18n;
};
export declare const GoodUIi18nProvider: FC<PropsWithChildren<{
    defaultLanguage?: string;
}>>;
export { locali18n };
//# sourceMappingURL=GoodUIi18nProvider.d.ts.map