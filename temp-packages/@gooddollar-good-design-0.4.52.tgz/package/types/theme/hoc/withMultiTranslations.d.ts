import React from "react";
declare const withTranslations: <P extends object>(WrappedComponent: React.ComponentType<P>, translationIds: {
    [key: string]: string;
}, restProps?: any) => (props: P) => React.JSX.Element;
export default withTranslations;
//# sourceMappingURL=withMultiTranslations.d.ts.map