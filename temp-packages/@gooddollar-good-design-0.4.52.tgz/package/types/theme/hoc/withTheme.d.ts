import React, { PropsWithChildren } from "react";
interface IWithThemeOpts {
    name?: string;
    skipProps?: string | string[];
}
export declare const withTheme: (options?: IWithThemeOpts) => <T>(Component: React.ComponentType<React.PropsWithChildren<T>>) => React.FC<T>;
export {};
//# sourceMappingURL=withTheme.d.ts.map