import { NativeBaseProviderProps } from "native-base";
import { ReactElement } from "react";
import "@formatjs/intl-locale/polyfill";
import "@formatjs/intl-pluralrules/polyfill";
import { FontID } from "./utils/fonts";
type ILoadFonts = {
    [fontId in FontID]?: boolean;
};
export declare const NativeBaseProvider: ({ children, ...props }: NativeBaseProviderProps & ILoadFonts) => ReactElement;
export {};
//# sourceMappingURL=NativeBaseProvider.d.ts.map