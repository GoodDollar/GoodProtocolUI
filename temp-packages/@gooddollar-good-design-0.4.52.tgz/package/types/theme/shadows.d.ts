declare const cardShadow: {
    shadowColor: string;
    shadowOffset: {
        width: number;
        height: number;
    };
    shadowOpacity: number;
    shadowRadius: number;
    elevation: number;
};
export { cardShadow };
//# sourceMappingURL=shadows.d.ts.map