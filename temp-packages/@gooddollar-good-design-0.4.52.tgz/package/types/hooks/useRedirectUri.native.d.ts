export declare const useRedirectUri: (redirectUrl: string | undefined) => string | undefined;
//# sourceMappingURL=useRedirectUri.native.d.ts.map