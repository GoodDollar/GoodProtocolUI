import React from "react";
import { TransactionState } from "@usedapp/core";
export declare const useSignWalletModal: () => {
    hideModal: () => void;
    showModal: () => void;
    SignWalletModal: ({ txStatus, ...props }: {
        txStatus?: TransactionState | undefined;
    }) => React.JSX.Element;
};
//# sourceMappingURL=useSignWalletModal.d.ts.map