import { PoolDetails, RecentClaims } from "@gooddollar/web3sdk-v2";
import type { ClaimContextProps } from "../apps/ubi/types";
export declare const useFormatClaimTransactions: (pools: PoolDetails[] | RecentClaims[] | undefined, chainId: number | undefined, account: string) => ClaimContextProps["claimPools"];
//# sourceMappingURL=useFormatTransactions.d.ts.map