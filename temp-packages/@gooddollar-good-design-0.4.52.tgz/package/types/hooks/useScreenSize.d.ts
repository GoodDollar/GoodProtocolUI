declare const useScreenSize: () => {
    isMobileView: any;
    isSmallTabletView: any;
    isTabletView: any;
    isDesktopView: any;
};
export default useScreenSize;
//# sourceMappingURL=useScreenSize.d.ts.map