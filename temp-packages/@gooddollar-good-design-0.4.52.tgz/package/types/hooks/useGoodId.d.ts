export declare const useGoodId: (account: string) => {
    certificates: import("@gooddollar/web3sdk-v2").AggregatedCertificate[];
    certificateSubjects: import("@gooddollar/web3sdk-v2").CredentialSubjectsByType;
    expiryDate: {
        authPeriod: import("ethers").BigNumber;
        expiryTimestamp: import("ethers").BigNumber;
        formattedExpiryTimestamp: string | undefined;
        lastAuthenticated: import("ethers").BigNumber;
    } | undefined;
    expiryFormatted: string | undefined;
    isWhitelisted: boolean;
    whitelistedRoot: string | null;
};
//# sourceMappingURL=useGoodId.d.ts.map