import React from "react";
type RedirectNoticeContextProps = {
    goToExternal: (e: any, url: string) => void;
    open: boolean;
    url: string;
    onClose: () => void;
};
export declare const RedirectNoticeProvider: ({ children }: {
    children: any;
}) => React.JSX.Element;
export declare const useRedirectNotice: () => RedirectNoticeContextProps;
export {};
//# sourceMappingURL=useRedirectNoticeModal.d.ts.map