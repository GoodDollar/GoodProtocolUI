export declare const useWindowFocus: () => {
    title: string;
};
//# sourceMappingURL=useWindowFocus.d.ts.map