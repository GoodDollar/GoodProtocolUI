export declare const useWindowFocus: () => {
    title: string;
};
//# sourceMappingURL=useWindowFocus.native.d.ts.map