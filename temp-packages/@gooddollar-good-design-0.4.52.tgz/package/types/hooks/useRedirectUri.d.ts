export declare const useRedirectUri: (redirectUrl: string | undefined) => string;
//# sourceMappingURL=useRedirectUri.d.ts.map