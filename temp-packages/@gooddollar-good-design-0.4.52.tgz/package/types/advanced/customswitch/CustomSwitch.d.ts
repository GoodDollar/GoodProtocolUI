import React from "react";
export declare const CustomSwitch: ({ list, switchListCb }: {
    list: string[];
    switchListCb: () => void;
}) => React.JSX.Element;
//# sourceMappingURL=CustomSwitch.d.ts.map