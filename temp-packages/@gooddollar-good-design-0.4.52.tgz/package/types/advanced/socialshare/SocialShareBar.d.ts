import React from "react";
export interface SocialShareBarProps {
    message: string;
    url: string;
    className?: string;
}
export declare const SocialShareBar: React.FC<SocialShareBarProps>;
export default SocialShareBar;
//# sourceMappingURL=SocialShareBar.d.ts.map