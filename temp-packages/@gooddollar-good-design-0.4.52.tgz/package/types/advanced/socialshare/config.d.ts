export interface SocialPlatform {
    id: string;
    name: string;
    color: string;
    icon: string;
    getUrl: (message: string, url: string) => string;
    note?: string;
}
export declare const SOCIALS: SocialPlatform[];
export declare const DEFAULT_MESSAGE = "I just did my first claim(s) of G$ this week!";
export declare const DEFAULT_URL = "https://gooddollar.org";
export declare const DEFAULT_ICON_BASE_PATH = "/assets/svg";
//# sourceMappingURL=config.d.ts.map