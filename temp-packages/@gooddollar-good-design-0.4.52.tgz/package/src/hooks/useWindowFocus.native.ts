export const useWindowFocus = () => ({
  title: ""
});
