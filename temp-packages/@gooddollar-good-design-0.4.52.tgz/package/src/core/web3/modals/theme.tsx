export * from "./BasicModal.theme";
