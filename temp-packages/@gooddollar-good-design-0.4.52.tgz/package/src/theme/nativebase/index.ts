export * from "./Text.theme";
