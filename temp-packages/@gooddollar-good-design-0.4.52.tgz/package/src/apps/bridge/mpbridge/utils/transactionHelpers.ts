import { ethers, utils } from "ethers";
import { getSourceChainId } from "@gooddollar/web3sdk-v2";
import { TransactionStatus } from "@usedapp/core";
import type { BridgeTransaction } from "../types";
import { capitalizeChain } from "../utils";

interface CreateTransactionDetailsParams {
  amountWei: string;
  sourceChain: string;
  targetChain: string;
  bridgeProvider: string;
  bridgeStatus: Partial<TransactionStatus> | undefined;
  bridgeToTxHash: string | undefined;
  date?: Date;
}

export const createTransactionDetails = (params: CreateTransactionDetailsParams): BridgeTransaction => {
  const { amountWei, sourceChain, targetChain, bridgeProvider, bridgeStatus, bridgeToTxHash, date } = params;

  const amountBN = ethers.BigNumber.from(amountWei || "0");
  const amountFormatted = utils.formatEther(amountBN);

  let status: "completed" | "pending" | "failed" | "bridging" = "pending";
  if (bridgeStatus?.status === "Fail" || bridgeStatus?.status === "Exception") {
    status = "failed";
  } else if (bridgeStatus?.status === "Mining") {
    status = "bridging";
  }

  const sourceChainId = getSourceChainId(sourceChain);
  const transactionHash = bridgeStatus?.transaction?.hash || bridgeToTxHash || "";

  return {
    id: transactionHash,
    transactionHash,
    sourceChain: capitalizeChain(sourceChain),
    targetChain: capitalizeChain(targetChain),
    amount: parseFloat(amountFormatted).toFixed(2),
    bridgeProvider: bridgeProvider as "axelar" | "layerzero",
    status,
    date: date ?? new Date(),
    chainId: sourceChainId
  };
};
