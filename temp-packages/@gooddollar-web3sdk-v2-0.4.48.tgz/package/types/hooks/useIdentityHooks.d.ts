export declare const useIdentityExpiryDate: (account: string) => [undefined, undefined, "pending"] | [undefined, Error, "rejected"] | [{
    authPeriod: import("ethers").BigNumber;
    expiryTimestamp: import("ethers").BigNumber;
    formattedExpiryTimestamp: string | undefined;
    lastAuthenticated: import("ethers").BigNumber;
} | undefined, undefined, "resolved"];
//# sourceMappingURL=useIdentityHooks.d.ts.map