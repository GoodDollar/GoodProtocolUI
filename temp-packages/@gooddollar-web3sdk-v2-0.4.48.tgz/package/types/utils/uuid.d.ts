export { v4 as default } from "uuid";
//# sourceMappingURL=uuid.d.ts.map