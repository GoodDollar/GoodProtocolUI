export declare const withTemporaryFile: (dataUrl: any, callback: any) => Promise<any>;
export declare const readAsDataURL: (file: any) => Promise<unknown>;
export declare const readAsText: (file: any, encoding?: string) => Promise<unknown>;
//# sourceMappingURL=fs.d.ts.map