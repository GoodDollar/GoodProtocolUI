export declare const fallback: (asyncFns: any, onFallback?: (error: any) => boolean) => Promise<any>;
export declare const batch: <T, R>(items: T[], chunkSize: number, onItem: any) => Promise<R[]>;
//# sourceMappingURL=async.d.ts.map