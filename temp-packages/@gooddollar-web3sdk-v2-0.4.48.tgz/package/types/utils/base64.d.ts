export declare const stripBase64: (dataURL: any) => any;
export declare const normalizeDataUrl: (dataURL: any, mime: any) => any;
export declare const parseDataUrl: (dataURL: any) => {
    mime: string;
    extension: string;
    base64: any;
};
//# sourceMappingURL=base64.d.ts.map