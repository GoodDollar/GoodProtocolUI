import { AppKitNetwork } from "@reown/appkit/networks";
export { useAppKit as useWeb3Modal, useDisconnect } from "@reown/appkit/react";
import { providers } from "ethers";
import { Props } from "../Web3Context";
export declare const useEthersProvider: ({ chainId }?: {
    chainId?: number | undefined;
}) => providers.Web3Provider | undefined;
export declare const Web3ModalProvider: ({ projectId, reownMetadata, appkitChains, children, config, env }: Props & {
    appkitChains?: [AppKitNetwork, ...AppKitNetwork[]] | undefined;
    projectId?: string | undefined;
    reownMetadata?: any;
}) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=Web3modalProvider.d.ts.map