import React from "react";
import { FeedFilter, FeedPost } from "../../sdk/newsfeed/StrapiCachedFeed";
import { IPFSUrls } from "../../sdk/ipfs/sdk";
type INewsFeedContext = {
    feed: FeedPost[];
};
export declare const NewsFeedContext: React.Context<INewsFeedContext>;
export interface INewsFeedProvider {
    children: any;
    feedFilter?: FeedFilter;
    env: string;
    newsfeedUrl?: string;
    ipfsUrls?: IPFSUrls;
    enablePeriodicSync?: boolean;
    limit?: number;
}
export declare const NewsFeedProvider: ({ children, feedFilter, env, newsfeedUrl, ipfsUrls, enablePeriodicSync, limit }: INewsFeedProvider) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=NewsFeedContext.d.ts.map