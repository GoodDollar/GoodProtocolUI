import React from "react";
import type { FC, PropsWithChildren } from "react";
type IGoodIdContext = {
    db: any;
};
export declare const GoodIdContext: React.Context<IGoodIdContext>;
interface IGoodIdContextProviderProps {
    localDb?: any;
}
export declare const GoodIdContextProvider: FC<PropsWithChildren<IGoodIdContextProviderProps>>;
export {};
//# sourceMappingURL=GoodIdContext.d.ts.map