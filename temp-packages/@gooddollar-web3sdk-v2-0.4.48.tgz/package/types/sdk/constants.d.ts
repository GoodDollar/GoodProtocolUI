import { EnvKey } from "./base/sdk";
import { CurrencyValue, Token } from "@usedapp/core";
import { BigNumber } from "ethers";
export declare enum SupportedChains {
    MAINNET = 1,
    FUSE = 122,
    CELO = 42220,
    XDC = 50
}
export type SUPPORTED_NETWORKS = "FUSE" | "CELO" | "MAINNET" | "XDC";
export declare enum SupportedV2Networks {
    FUSE = 122,
    CELO = 42220,
    XDC = 50
}
export interface G$Balances {
    G$: CurrencyValue;
    GOOD: CurrencyValue;
}
export type G$Token = keyof G$Balances;
export type G$DecimalsByChain = Partial<Record<SupportedChains, number>>;
export type G$DecimalsMap = {
    G$: G$DecimalsByChain;
    GOOD: G$DecimalsByChain;
};
export declare const G$Decimals: G$DecimalsMap;
export declare const G$Tokens: (keyof G$Balances)[];
export type SupportedV2Network = keyof typeof SupportedV2Networks;
export declare const Envs: {
    [key: EnvKey]: {
        [key: string]: string;
    };
};
type ObjectLike = {
    [key: string]: string | ObjectLike | Array<string[]> | string[] | number;
};
export declare const G$TokenContracts: {
    G$: {
        contract: string;
        name: string;
        ticker: string;
    };
    GOOD: {
        contract: string;
        name: string;
        ticker: string;
    };
};
export declare function G$Token(tokenName: G$Token, chainId: number, env: string, decimalsMap?: G$DecimalsMap): Token;
export declare function G$Amount(tokenName: G$Token, value: BigNumber, chainId: number, env: string, decimalsMap?: G$DecimalsMap): CurrencyValue;
export declare function formatAmount(value: BigNumber, tokenDecimals: number, displayDecimals?: number, currencyFormatOptions?: any, tokenName?: string, tokenSymbol?: string): string;
export declare function G$ContractAddresses<T = ObjectLike>(name: string, env: EnvKey): T;
export declare const FV_LOGIN_MSG = "Sign this message to login into GoodDollar Unique Identity service.\nWARNING: do not sign this message unless you trust the website/application requesting this signature.\nnonce:";
export declare const FV_IDENTIFIER_MSG2 = "Sign this message to request verifying your account <account> and to create your own secret unique identifier for your anonymized record.\nYou can use this identifier in the future to delete this anonymized record.\nWARNING: do not sign this message unless you trust the website/application requesting this signature.";
export declare function submitReferral({ txHash, chainId, baseUrl }: {
    txHash: string;
    chainId: number;
    baseUrl?: string;
}): Promise<Response>;
export {};
//# sourceMappingURL=constants.d.ts.map