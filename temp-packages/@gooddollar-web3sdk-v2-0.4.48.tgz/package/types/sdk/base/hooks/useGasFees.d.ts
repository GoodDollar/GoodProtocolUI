import { FeeData } from "@ethersproject/providers";
import { ContractFunctionNames, Falsy, Params, TransactionOptions, TypedContract } from "@usedapp/core/dist/esm/src/model";
export declare const useGasFees: () => FeeData;
export declare function useContractFunctionWithDefaultGasFees<T extends TypedContract, FN extends ContractFunctionNames<T>>(contract: T | Falsy, functionName: FN, options?: TransactionOptions, estGasEnabled?: boolean): {
    send: (...args: Params<T, FN>) => Promise<import("@ethersproject/abstract-provider").TransactionReceipt | undefined>;
    state: import("@usedapp/core").TransactionStatus;
    events: import("@ethersproject/abi").LogDescription[] | undefined;
    resetState: () => void;
};
//# sourceMappingURL=useGasFees.d.ts.map