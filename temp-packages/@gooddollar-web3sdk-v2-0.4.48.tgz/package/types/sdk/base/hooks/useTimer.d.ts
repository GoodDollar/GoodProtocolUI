import { Dispatch, SetStateAction } from "react";
declare const useTimer: (tillTime?: Date) => [string | undefined, boolean, Dispatch<SetStateAction<Date | undefined>>];
export default useTimer;
//# sourceMappingURL=useTimer.d.ts.map