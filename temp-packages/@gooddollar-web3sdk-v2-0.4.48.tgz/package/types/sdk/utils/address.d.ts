export declare const ZERO_ADDRESS = "0x0000000000000000000000000000000000000000";
export declare const isZeroAddress: (address: string | null | undefined) => boolean;
export declare const isValidWhitelistedRoot: (address: string | null | undefined) => boolean;
export declare const isNonZeroAddress: (address: string | null | undefined) => boolean;
//# sourceMappingURL=address.d.ts.map