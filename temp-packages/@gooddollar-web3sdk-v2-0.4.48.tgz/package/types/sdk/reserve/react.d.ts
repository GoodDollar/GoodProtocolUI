import { BigNumber, ethers } from "ethers";
import { QueryParams } from "@usedapp/core";
export declare const useExchange: (requiredChainId?: number) => {
    exchange: any;
    exchangeId: any;
};
export declare const useReserveToken: (requiredChainId?: number) => {
    chainId: number;
    address: any;
    decimals: any;
    symbol: any;
    name: any;
};
export declare const useG$Price: (refresh?: QueryParams["refresh"], requiredChainId?: number) => BigNumber | undefined;
export declare const useSwapMeta: (account: string, buying: boolean, slippageTolerance: number, input?: BigNumber, output?: BigNumber, refresh?: QueryParams["refresh"]) => {
    minAmountOut: any;
    g$Price: BigNumber | undefined;
    g$Allowance: BigNumber | undefined;
    cusdAllowance: BigNumber | undefined;
    exitContribution: number;
    amountIn: any;
    amountOut: any;
    exchangeId: any;
    mentoBroker: string;
    reserveAsset: any;
    g$: string;
};
export declare const useSwap: (inputToken: string, outputToken: string, exactInput?: {
    input: string;
    minAmountOut: string;
}, exactOutput?: {
    output: string;
    maxAmountIn: string;
}) => {
    approve: {
        send: (...args: any[]) => Promise<ethers.providers.TransactionReceipt | undefined>;
        state: import("@usedapp/core").TransactionStatus;
        events: ethers.utils.LogDescription[] | undefined;
        resetState: () => void;
    };
    swap: {
        send: (...args: any[]) => Promise<ethers.providers.TransactionReceipt | undefined>;
        state: import("@usedapp/core").TransactionStatus;
        events: ethers.utils.LogDescription[] | undefined;
        resetState: () => void;
    };
};
//# sourceMappingURL=react.d.ts.map