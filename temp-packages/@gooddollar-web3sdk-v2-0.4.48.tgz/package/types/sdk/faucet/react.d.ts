import { QueryParams } from "@usedapp/core";
export declare const useFaucet: (refresh?: QueryParams["refresh"]) => void;
//# sourceMappingURL=react.d.ts.map