import * as ethers from "ethers";
import { EnvKey } from "../../sdk";
export declare const useBuyGd: ({ donateOrExecTo, callData, withSwap, env }: {
    donateOrExecTo?: string | undefined;
    callData?: string | undefined;
    withSwap?: boolean | undefined;
    env?: string | undefined;
}) => {
    createAndSwap: (minAmount: ethers.BigNumberish) => Promise<ethers.ethers.providers.TransactionReceipt | undefined>;
    swap: (minAmount: ethers.BigNumberish) => Promise<ethers.ethers.providers.TransactionReceipt | undefined>;
    triggerSwapTx: () => Promise<Response>;
    swapState: import("@usedapp/core").TransactionStatus;
    createState: import("@usedapp/core").TransactionStatus;
    gdHelperAddress: any;
};
//# sourceMappingURL=react.d.ts.map