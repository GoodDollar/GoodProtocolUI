export declare const toV1: (cid: any) => string;
export declare const cidRegexp: RegExp;
export declare const isValidCID: (source: any) => boolean;
export type IPFSUrls = {
    ipfsGateways: string;
    ipfsUploadGateway: string;
};
export declare const defaulIPFS: IPFSUrls;
export declare class IpfsStorage {
    client: any;
    gateways: any;
    constructor(ipfsUrls?: IPFSUrls);
    store(dataUrl: any): Promise<string>;
    load(cid: any): Promise<unknown>;
    _lookupGateways(cid: any): Promise<any>;
    _requestGateway: (cid: any, v1: any, gateway: any) => Promise<any>;
}
//# sourceMappingURL=sdk.d.ts.map