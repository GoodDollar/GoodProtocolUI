import { BigNumber } from "ethers";
import { BaseSDK } from "../base/sdk";
export declare class ClaimSDK extends BaseSDK {
    generateFVLink(firstName: string, callbackUrl?: string, popupMode?: boolean, chainId?: number): Promise<string>;
    getFVLink(chainId?: number): {
        getLoginSig: () => Promise<string>;
        getFvSig: () => Promise<string>;
        getLink: (firstName: string, callbackUrl?: string, popupMode?: boolean, chainId?: number | undefined) => string;
        deleteFvId: () => Promise<void>;
    };
    getWhitelistedRoot(address: string): Promise<string>;
    isAddressVerified(address: string): Promise<boolean>;
    checkEntitlement(address?: string): Promise<BigNumber>;
    getNextClaimTime(): Promise<Date>;
    claim(txOverrides?: object): Promise<import("ethers").ContractTransaction>;
    deleteFVRecord(): Promise<import("../goodid/sdk").ParsedBody>;
}
//# sourceMappingURL=sdk.d.ts.map