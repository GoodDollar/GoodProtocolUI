import { IIdentity, UBIScheme } from "@gooddollar/goodprotocol/types";
import { ChainId, QueryParams } from "@usedapp/core";
import { BigNumber } from "ethers";
export declare const useWhitelistedRoot: (identity: IIdentity | undefined, account: string | undefined, refresh: QueryParams["refresh"], chainId: ChainId) => string | undefined;
export declare const useEntitlementForRoot: (ubi: UBIScheme | undefined, root: string | undefined, refresh: QueryParams["refresh"], chainId: ChainId) => BigNumber | undefined;
//# sourceMappingURL=hooks.d.ts.map