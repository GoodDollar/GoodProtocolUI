export interface RecentClaims {
    address: string;
    claimAmount: string;
    date: string;
    transactionHash: string;
}
export declare const getRecentClaims: (account: string, endpoints: string, library: any, pools: Array<string>, withPools: boolean) => Promise<RecentClaims[] | undefined>;
//# sourceMappingURL=getRecentClaims.d.ts.map