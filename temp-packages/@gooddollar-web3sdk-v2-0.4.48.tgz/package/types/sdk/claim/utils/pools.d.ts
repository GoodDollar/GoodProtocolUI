import ethers from "ethers";
import { PoolDetails } from "../types";
export declare const getContractsFromClaimPools: (poolsDetails: PoolDetails[]) => ethers.ethers.Contract[];
export declare const getPoolsDetails: (pools: {
    [key: string]: any;
}, abi: ethers.ethers.ContractInterface, library: ethers.providers.JsonRpcProvider | ethers.providers.FallbackProvider) => any;
//# sourceMappingURL=pools.d.ts.map