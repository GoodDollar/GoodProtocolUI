import { UBIScheme } from "@gooddollar/goodprotocol/types";
import { QueryParams } from "@usedapp/core";
import ethers, { BigNumber } from "ethers";
import { EnvKey } from "../base/sdk";
import { SupportedV2Networks } from "../constants";
import { PoolDetails } from "./types";
export declare const useFVLink: (chainId?: number) => {
    getLoginSig: () => Promise<string>;
    getFvSig: () => Promise<string>;
    getLink: (firstName: string, callbackUrl?: string | undefined, popupMode?: boolean, chainId?: number | undefined) => string;
    deleteFvId: () => Promise<void>;
};
export declare const isTxReject: (errorMessage: string) => boolean;
export declare const useIsAddressVerified: (address: string, env?: EnvKey) => [undefined, undefined, "pending"] | [undefined, Error, "rejected"] | [{
    isVerified: boolean;
    whitelistedRoot: string;
} | {
    isVerified: boolean;
    whitelistedRoot: null;
}, undefined, "resolved"];
export declare const useMultiClaim: (poolsDetails: PoolDetails[] | undefined) => {
    poolContracts: ethers.ethers.Contract[] | undefined;
    claimFlowStatus: {
        isClaimingDone: boolean;
        remainingClaims: number | undefined;
        error: boolean;
        isClaiming: boolean;
        claimReceipts: any[] | undefined;
    };
    startClaiming: () => Promise<void>;
    updateStatus: () => Promise<void>;
};
export declare const useGetMemberUBIPools: () => {
    poolsDetails: PoolDetails[] | undefined;
    loading: boolean;
    error: string | null;
    fetchPools: () => Promise<void>;
};
export declare const useGetUBIPoolsDetails: (poolAddress: string[]) => {
    ubiSettings: import("@gooddollar/goodcollective-contracts").UBIPool.UBISettingsStruct;
    status: import("@gooddollar/goodcollective-sdk").UBIPoolStatus;
    contract: string;
    isRegistered?: boolean | undefined;
    claimAmount?: ethers.ethers.BigNumberish | undefined;
    nextClaimTime: ethers.ethers.BigNumberish;
    nextClaimAmount: ethers.ethers.BigNumberish;
    poolDetails?: {
        ipfs: string;
        isVerified: boolean;
        projectId: string;
    } | undefined;
}[] | undefined;
export declare const useClaim: (refresh?: QueryParams["refresh"]) => {
    isWhitelisted: boolean;
    whitelistedRoot: string | undefined;
    claimAmount: ethers.ethers.BigNumber | undefined;
    hasClaimed: boolean | undefined;
    nextClaimTime: Date;
    address: string;
    contract: UBIScheme;
    contractName: string;
};
export declare const useHasClaimed: (requiredNetwork: keyof typeof SupportedV2Networks) => BigNumber | undefined;
export declare const useClaimedAlt: (chainId: number | undefined) => {
    hasClaimed: boolean;
    altChain: number;
};
export declare const useWhitelistSync: () => {
    celoWhitelisted: boolean;
    currentWhitelisted: boolean;
    syncStatus: Promise<boolean> | undefined;
};
//# sourceMappingURL=react.d.ts.map