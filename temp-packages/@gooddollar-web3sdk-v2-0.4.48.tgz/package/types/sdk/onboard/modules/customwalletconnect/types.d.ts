export type WcConnectOptions = {
    customLabelFor: string;
    handleUri?: (uri: string) => Promise<unknown>;
    connectFirstChainId?: boolean;
    bridge?: string;
    qrcodeModalOptions?: {
        mobileLinks: string[];
    };
} & {
    projectId: string;
    version: 2;
    requiredChains?: number[] | undefined;
};
export declare enum CustomLabels {
    zengo = "ZenGo",
    gooddollar = "GoodDollar Wallet",
    valora = "Valora"
}
//# sourceMappingURL=types.d.ts.map