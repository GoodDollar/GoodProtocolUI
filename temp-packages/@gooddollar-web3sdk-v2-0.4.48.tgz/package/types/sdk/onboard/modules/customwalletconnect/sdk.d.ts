import { WalletConnectOptions } from "@web3-onboard/walletconnect/dist/types";
import { CustomLabels } from "./types";
import { WalletInit } from "@web3-onboard/common";
export declare const customwc: (options: WalletConnectOptions & {
    label: keyof typeof CustomLabels;
}) => WalletInit;
//# sourceMappingURL=sdk.d.ts.map