export declare const icons: {
    gooddollar: {
        svg: any;
        webp: any;
    };
    zengo: {
        svg: any;
        webp: any;
    };
    metamask: {
        svg: undefined;
        webp: any;
    };
    valora: {
        svg: any;
        webp: any;
    };
    safe: {
        svg: undefined;
        webp: any;
    };
    celosafe: {
        svg: undefined;
        webp: any;
    };
    fusesafe: {
        svg: undefined;
        webp: any;
    };
};
//# sourceMappingURL=icons.d.ts.map