import React from "react";
import { InitOptions } from "@web3-onboard/core";
import { WalletConnectOptions } from "@web3-onboard/walletconnect/dist/types";
export interface IOnboardWallets {
    valora?: boolean;
    gd?: boolean;
    metamask?: boolean;
    walletconnect?: boolean;
    coinbase?: boolean;
    zengo?: boolean;
    custom?: InitOptions["wallets"];
}
export interface IOnboardProviderProps {
    options?: Omit<InitOptions, "wallets">;
    wallets?: IOnboardWallets | null;
    wc2Options?: WalletConnectOptions | object;
    gdEnv?: string;
    children?: React.ReactNode;
}
export declare const wc2InitOptions: {
    projectId: string;
    version: number;
    qrModalOptions: {
        optionalChains: number[];
        themeVariables: never[];
        chainImages: never[];
        enableExplorer: boolean;
        explorerAllowList: never[];
        explorerDenyList: never[];
        privacyPolicyUrl: any;
        tokenImages: never[];
        termsOfServiceUrl: string;
        themeMode: string;
        walletImages: {
            valora: any;
            zengo: any;
            gooddollar: any;
            celosafe: any;
            safe: any;
            fusesafe: any;
            metamask: any;
        };
        mobileWallets: ({
            id: string;
            name: string;
            links: {
                universal: string;
                native: string;
            };
        } | {
            id: string;
            name: string;
            links: {
                universal: string;
                native?: undefined;
            };
        })[];
    };
};
export declare const OnboardProvider: React.MemoExoticComponent<({ options, wallets, wc2Options, gdEnv, children }: IOnboardProviderProps) => JSX.Element>;
//# sourceMappingURL=react.d.ts.map