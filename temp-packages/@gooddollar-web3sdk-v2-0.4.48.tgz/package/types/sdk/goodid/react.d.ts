import GeoLocation from "@react-native-community/geolocation";
import { Certificate, CertificateItem, CredentialSubjectsByType, CredentialType, PoolCriteria } from "./types";
export interface AggregatedCertificate extends Partial<CertificateItem> {
    key: string;
    type: CredentialType;
    typeName: keyof typeof CredentialType;
}
export declare const useCertificates: (account: string, onDatabaseUpdated?: () => Promise<unknown>) => {
    loadCertificates: CertificateItem[] | null | undefined;
    getCertificate: (type: CredentialType) => Promise<Certificate | undefined>;
    storeCertificate: (certificate: Certificate) => Promise<void>;
    deleteCertificate: (primaryKeys: string[]) => Promise<void>;
};
export declare const useAggregatedCertificates: (account: string) => AggregatedCertificate[];
export interface GeoLocation {
    location: [number, number] | null;
}
export declare const useGeoLocation: () => [location: GeoLocation, error: string | null];
export declare const useIssueCertificates: (account: string | undefined, baseEnv: any) => (account: string, geoLocation: GeoLocation | undefined, fvsig: string) => Promise<void>;
export declare const useCertificatesSubject: (certificates: AggregatedCertificate[]) => CredentialSubjectsByType;
export interface CheckAvailableOffersProps {
    account: string;
    pools: PoolCriteria[];
    isDev: boolean;
    onDone?: (skipOffer: boolean) => void;
}
export declare const useCheckAvailableOffers: ({ account, pools, isDev, onDone }: CheckAvailableOffersProps) => false | PoolCriteria[] | null;
//# sourceMappingURL=react.d.ts.map