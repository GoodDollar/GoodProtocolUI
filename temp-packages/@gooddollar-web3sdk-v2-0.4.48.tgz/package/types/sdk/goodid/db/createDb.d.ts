import Dexie from "dexie";
export declare const createCertificatesDb: () => Dexie;
//# sourceMappingURL=createDb.d.ts.map