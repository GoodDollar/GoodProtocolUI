import { Signer } from "ethers";
import { EnvKey } from "../base";
import { CertificateItem, CertificateSubject, PoolCriteria } from "./types";
export declare const getDevEnv: (baseEnv: string) => string;
export interface ParsedBody {
    ok?: number;
    success?: boolean;
    error?: string;
    [key: string]: any;
}
export declare const g$Response: (response: Response) => Promise<ParsedBody>;
export declare const g$Request: (json: any, method?: string, headers?: {}) => {
    method: string;
    headers: {
        "content-type": string;
    };
    body: string;
};
export declare const g$AuthRequest: (token: string, json: any, method?: string) => {
    method: string;
    headers: {
        "content-type": string;
    };
    body: string;
};
export declare function fvAuth(env: EnvKey, address: string, fvSig: string): Promise<{
    token: string;
    fvsig: string;
}>;
export declare function fvAuth(env: EnvKey, signer: Signer): Promise<{
    token: string;
    fvsig: string;
}>;
export declare const requestLocationCertificate: (baseEnv: string, [lat, long]: [number, number], fvSig: string, account: string) => Promise<CertificateItem>;
export declare const requestIdentityCertificate: (baseEnv: string, fvSig: string, account: string) => Promise<CertificateItem>;
type CriteriaMatcher = (certificateSubject: CertificateSubject, criteria: any) => boolean;
export declare const criteriaMatchers: Record<string, CriteriaMatcher>;
export declare const checkCriteriaMatch: (certificateSubject: any, criteria: any, criteriaType: keyof PoolCriteria) => boolean;
export {};
//# sourceMappingURL=sdk.d.ts.map