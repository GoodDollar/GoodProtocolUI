import { PostHogOptions } from "posthog-react-native";
import { IAbstractProvider, IAnalyticsProvider, IAppProps, IAbstractConfig } from "../types";
export interface IPostHogConfig extends PostHogOptions, IAbstractConfig {
    apiKey?: string;
}
export declare class PostHog implements IAbstractProvider, IAnalyticsProvider {
    private config;
    private api;
    constructor(config: any);
    initialize(appProps: IAppProps): Promise<boolean>;
    identify(identifier: string | number, email?: string, props?: object): void;
    send(event: string, data?: object): void;
}
//# sourceMappingURL=posthog.d.ts.map