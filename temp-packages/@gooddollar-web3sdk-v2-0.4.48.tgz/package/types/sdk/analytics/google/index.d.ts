export { default as GoogleAPIFactory } from "./api";
export * from "./GoogleAnalytics";
export * from "./types";
//# sourceMappingURL=index.d.ts.map