export * as api from "@sentry/browser";
//# sourceMappingURL=api.d.ts.map