export * as api from "@sentry/react-native";
//# sourceMappingURL=api.native.d.ts.map