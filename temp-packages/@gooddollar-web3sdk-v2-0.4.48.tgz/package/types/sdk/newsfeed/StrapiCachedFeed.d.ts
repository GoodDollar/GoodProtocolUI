import { IpfsStorage } from "../ipfs/sdk";
import { EnvKey } from "../base";
export type FeedFilter = {
    context?: string;
    tag?: string;
};
export interface FeedPost {
    id: string;
    link: string;
    title: string;
    content: string;
    picture: string;
    published: string;
    updated: string;
    sponsored_link: string;
    sponsored_logo: string;
}
interface NewsFeedOptions {
    baseUrl: string;
    env: EnvKey;
    pageSize?: number;
}
export declare class StrapiCachedFeed {
    IPFS_BATCH: number;
    SYNC_PERIOD: number;
    PAGE_SIZE: number;
    filter: FeedFilter;
    db: any;
    IPFS: any;
    ready: Promise<void>;
    baseUrl: string;
    pageSize: number;
    constructor(filter: FeedFilter | undefined, ipfs: IpfsStorage, options?: NewsFeedOptions);
    periodicSync: (callback?: () => void) => Promise<void>;
    syncPosts: (page?: number) => any;
    _loadPostPictures(documentOrFeed: FeedPost | FeedPost[]): Promise<FeedPost | FeedPost[]>;
    getPosts(offset?: number, limit?: number): Promise<Array<FeedPost>>;
    private _fetchStrapiPosts;
    private _mapStrapiPost;
    private _shouldFetchMore;
    private _fetchPictureAsDataUrl;
    private _arrayBufferToBase64;
}
export {};
//# sourceMappingURL=StrapiCachedFeed.d.ts.map