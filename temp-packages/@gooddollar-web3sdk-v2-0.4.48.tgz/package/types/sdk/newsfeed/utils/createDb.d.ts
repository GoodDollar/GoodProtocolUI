import Dexie from "dexie";
export declare const createNewsFeedDb: () => Dexie;
//# sourceMappingURL=createDb.d.ts.map