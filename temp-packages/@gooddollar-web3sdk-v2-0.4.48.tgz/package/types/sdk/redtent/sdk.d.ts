export declare const uploadToS3: (base64: string, filename: string) => Promise<import("@aws-sdk/client-s3").PutObjectCommandOutput>;
//# sourceMappingURL=sdk.d.ts.map