export declare const useRegisterRedtent: () => (data: {
    videoFilename: string;
    certificates: Array<any>;
}) => Promise<import("../goodid/sdk").ParsedBody>;
//# sourceMappingURL=react.d.ts.map