import { ethers } from "ethers";
export declare const MPB_STATIC_DATA_CACHE_TTL_MS: number;
export type MPBStaticBridgeData = {
    minAmount: ethers.BigNumber;
    txLimit: ethers.BigNumber;
    protocolFeeBps: ethers.BigNumber;
};
export declare const fetchMPBStaticBridgeData: (contract: ethers.Contract, chainId: number) => Promise<MPBStaticBridgeData>;
export declare const clearMPBStaticBridgeDataCache: () => void;
//# sourceMappingURL=cache.d.ts.map