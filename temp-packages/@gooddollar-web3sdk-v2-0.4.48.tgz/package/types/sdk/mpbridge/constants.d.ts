import { ethers } from "ethers";
export declare const BRIDGE_CONSTANTS: {
    readonly DEFAULT_CHAIN_ID: 42220;
    readonly DEBOUNCE_DELAY: 300;
    readonly POLLING_INTERVAL: 5000;
    readonly BRIDGE_ID_TOPIC_INDEX: 6;
    readonly PRODUCTION_GDOLLAR_ADDRESS: "0x62B8B11039FcfE5aB0C56E502b1C372A3d2a9c7A";
    readonly GDOLLAR_ADDRESSES: {
        readonly 122: "0x495d133B938596C9984d462F007B676bDc57eCEC";
        readonly 42220: "0x62B8B11039FcfE5aB0C56E502b1C372A3d2a9c7A";
        readonly 1: "0x67c5870b4a41d4ebef24d2456547a03f1f3e094b";
        readonly 50: "0xEC2136843a983885AebF2feB3931F73A8eBEe50c";
    };
};
export declare const VALIDATION_REASONS: {
    readonly MIN_AMOUNT: "minAmount";
    readonly MAX_AMOUNT: "maxAmount";
    readonly CANNOT_BRIDGE: "cannotBridge";
    readonly ERROR: "error";
    readonly INSUFFICIENT_BALANCE: "insufficientBalance";
    readonly INVALID_CHAIN: "invalidChain";
};
export declare const ERROR_MESSAGES: {
    readonly BRIDGE_LIMITS_ERROR: "Something went wrong while determining transaction limits. Please try again later.";
    readonly BRIDGE_ELIGIBILITY_ERROR: "Unable to verify bridge eligibility. Please try again later.";
    readonly BRIDGE_SERVICE_UNAVAILABLE: "Bridge service is currently unavailable. Please try again later.";
    readonly BRIDGE_FEES_ERROR: "Failed to fetch bridge fees. Please try again later.";
    readonly BRIDGE_FEES_UNAVAILABLE: "Bridge fees not available for this route";
    readonly TRANSACTION_LIMITS_UNAVAILABLE: "Transaction limits unavailable";
    readonly UNEXPECTED_ERROR: "An unexpected error occurred. Please try again later.";
};
export declare const CHAIN_NAMES: {
    readonly FUSE: "fuse";
    readonly CELO: "celo";
    readonly MAINNET: "mainnet";
    readonly XDC: "xdc";
};
export declare const BRIDGE_PROVIDERS: {
    readonly LAYERZERO: "layerzero";
    readonly AXELAR: "axelar";
};
export type ChainName = "fuse" | "celo" | "mainnet" | "xdc";
export type BridgeProvider = "axelar" | "layerzero";
export type ValidationReason = "minAmount" | "maxAmount" | "cannotBridge" | "error" | "insufficientBalance" | "invalidChain";
export declare const VALIDATION_ERROR_MESSAGES: Record<ValidationReason, string>;
export declare const CHAIN_MAPPING: Record<number, ChainName>;
export declare const REVERSE_CHAIN_MAPPING: Record<ChainName, number>;
export declare const NATIVE_TOKEN_SYMBOLS: Record<ChainName, string>;
export declare const FEE_ROUTES: Record<BridgeProvider, Record<string, string>>;
export declare const normalizeAmountTo18: (amount: ethers.BigNumber, sourceChainId: number) => ethers.BigNumber;
export declare const resetStates: (setLoading: (loading: boolean) => void, setError: (error: string | null) => void) => void;
export declare const createEmptyBridgeFees: () => {
    nativeFee: ethers.BigNumber | null;
    zroFee: ethers.BigNumber | null;
};
export declare const handleError: (error: any, operation: string, setError: (error: string) => void, setState?: ((value: any) => void) | undefined, fallbackValue?: any) => void;
export declare const getChainName: (chainId: number) => ChainName;
export declare const getChainId: (chainName: string) => number;
export declare const getTargetChainId: (chainName: string) => number;
export declare const getSourceChainId: (chainName: string) => number;
export declare const isSupportedChain: (chainId: number) => boolean;
export declare const getFeeString: (fees: any, provider: BridgeProvider, sourceChain: string, targetChain: string) => string | null;
export declare const getNativeTokenSymbol: (chainName: string) => string;
export declare const parseFeeToWei: (feeString: string) => ethers.BigNumber;
export declare const calculateBridgeFees: (fees: any, provider: BridgeProvider, sourceChain: string, targetChain: string) => {
    nativeFee: ethers.BigNumber | null;
    zroFee: ethers.BigNumber | null;
};
//# sourceMappingURL=constants.d.ts.map