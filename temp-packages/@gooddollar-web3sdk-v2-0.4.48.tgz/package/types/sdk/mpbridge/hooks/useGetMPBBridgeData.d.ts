import { BridgeProvider } from "../constants";
import { MPBBridgeData, MPBBridgeReadOnlyUrls } from "../types";
export interface ValidationResult {
    isValid: boolean;
    reason: string;
    errorMessage?: string;
    canBridge: boolean;
    hasAllowance: boolean;
}
export declare const useGetMPBBridgeData: (sourceChain?: string, targetChain?: string, bridgeProvider?: BridgeProvider, amount?: string, address?: string, readOnlyUrls?: MPBBridgeReadOnlyUrls) => MPBBridgeData & {
    validation: ValidationResult;
};
//# sourceMappingURL=useGetMPBBridgeData.d.ts.map