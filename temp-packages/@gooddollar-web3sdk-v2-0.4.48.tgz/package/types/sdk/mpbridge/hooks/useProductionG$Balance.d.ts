import { QueryParams, CurrencyValue } from "@usedapp/core";
export declare function useProductionG$Balance(refresh?: QueryParams["refresh"], requiredChainId?: number): {
    G$: CurrencyValue;
};
//# sourceMappingURL=useProductionG$Balance.d.ts.map