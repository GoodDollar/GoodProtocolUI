import { MPBBridgeReadOnlyUrls, UseMPBBridgeReturn } from "../types";
import { BridgeProvider } from "../constants";
export declare const useMPBBridge: (bridgeProvider?: BridgeProvider, readOnlyUrls?: MPBBridgeReadOnlyUrls) => UseMPBBridgeReturn;
//# sourceMappingURL=useMPBBridge.d.ts.map