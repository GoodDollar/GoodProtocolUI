import { ethers } from "ethers";
import { MPBBridgeReadOnlyUrls } from "../types";
export declare const useMPBBridgeReadOnlyProvider: (chainId: number, readOnlyUrls?: MPBBridgeReadOnlyUrls) => ethers.providers.JsonRpcProvider | undefined;
export declare const useMPBBridgeContracts: (chainId: number, readOnlyUrls?: MPBBridgeReadOnlyUrls) => {
    provider: ethers.providers.JsonRpcProvider | undefined;
    bridgeContract: ethers.Contract | null;
    tokenContract: ethers.Contract | null;
};
//# sourceMappingURL=useMPBBridgeContracts.d.ts.map