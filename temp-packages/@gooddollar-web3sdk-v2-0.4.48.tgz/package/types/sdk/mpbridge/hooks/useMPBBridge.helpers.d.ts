export declare const getTransactionErrorMessage: (error: any) => string;
export declare const isTransientBlockReadError: (error: any) => boolean;
//# sourceMappingURL=useMPBBridge.helpers.d.ts.map