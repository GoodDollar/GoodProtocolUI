import { TransactionStatus } from "@usedapp/core";
import { ethers } from "ethers";
import { BridgeRequest, MPBBridgeReadOnlyUrls } from "../types";
export declare const extractBridgeRequestId: (logs: any[], bridgeContract: any) => string | undefined;
export declare const useBridgeMonitoring: (bridgeRequest: BridgeRequest | undefined, bridgeContract: ethers.Contract | null, approveState: TransactionStatus, bridgeToState: TransactionStatus, isSwitchingChain: boolean, switchChainError: string | undefined, readOnlyUrls?: MPBBridgeReadOnlyUrls) => {
    bridgeStatus: Partial<TransactionStatus> | undefined;
    bridgeRequestId: string | undefined;
    bridgeCompletedEvent: ethers.Event | undefined;
};
//# sourceMappingURL=useBridgeMonitoring.d.ts.map