import { SupportedChains } from "../../constants";
import { MPBBridgeReadOnlyUrls } from "../types";
export type MPBBridgeHistoryReadOnlyUrls = MPBBridgeReadOnlyUrls;
export type UseMPBBridgeHistoryOptions = {
    readOnlyUrls?: MPBBridgeHistoryReadOnlyUrls;
    chainIds?: SupportedChains[];
};
export declare const useMPBBridgeHistory: ({ readOnlyUrls, chainIds }?: UseMPBBridgeHistoryOptions) => {
    history: undefined;
    historySorted: undefined;
    initialLoading: boolean;
    refreshing: boolean;
    errorsByChain: Record<number, string>;
    refreshHistory: () => void;
} | {
    history: any[];
    historySorted: any[];
    initialLoading: boolean;
    refreshing: boolean;
    errorsByChain: Record<number, string>;
    refreshHistory: () => void;
};
//# sourceMappingURL=useMPBBridgeHistory.d.ts.map