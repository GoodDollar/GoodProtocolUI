export type BridgeEventName = "BridgeRequest" | "ExecutedTransfer";
export type CachedBridgeEvent = {
    transactionHash: string;
    blockHash: string;
    blockNumber: number;
    transactionIndex: number;
    removed: boolean;
    sourceChainId: number;
    from?: string;
    to?: string;
    targetChainId: string;
    amount: string;
    timestamp: string;
    bridge?: string;
    id?: string;
};
export type ChainSyncErrorState = {
    message: string;
    updatedAt: number;
};
export type ChainSyncState = {
    lastSyncedBlock?: number;
    lastSuccessfulSyncAt?: number;
    error?: ChainSyncErrorState;
};
export type MPBBridgeHistoryCache = {
    BridgeRequest?: CachedBridgeEvent[];
    ExecutedTransfer?: CachedBridgeEvent[];
    chains?: Partial<Record<number, ChainSyncState>>;
};
export declare const HISTORY_BLOCK_CHUNK_SIZE = 500;
export declare const HISTORY_LOOKBACK_BLOCKS = 5000;
export declare const getHistoryStartBlock: (latestBlock: number, lastSyncedBlock?: number) => number;
export declare const createBlockChunks: (fromBlock: number, toBlock: number, chunkSize?: number) => {
    fromBlock: number;
    toBlock: number;
}[];
export declare const getAddressTopic: (address?: string) => string | undefined;
export declare const createAccountEventTopics: (eventTopic: string, account?: string) => (string | null)[][];
export declare const dedupeLogs: <T extends {
    transactionHash: string;
    logIndex?: number | undefined;
}>(logs: T[]) => T[];
export declare const mergeBridgeHistoryCache: (current: MPBBridgeHistoryCache, nextEvents: Partial<Record<BridgeEventName, CachedBridgeEvent[]>>, nextChains: Partial<Record<number, ChainSyncState>>) => MPBBridgeHistoryCache;
export declare const getErrorsByChain: (cache: MPBBridgeHistoryCache) => Record<number, string>;
//# sourceMappingURL=useMPBBridgeHistory.helpers.d.ts.map