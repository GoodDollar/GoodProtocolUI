import { ethers } from "ethers";
import { BridgeRequest } from "../types";
import { BridgeProvider } from "../constants";
export declare const useLayerZeroFee: (bridgeContract: ethers.Contract | null, bridgeProvider: BridgeProvider, account: string | undefined | null) => {
    computeLayerZeroFee: (request: BridgeRequest, fallbackFee?: ethers.BigNumber | null) => Promise<ethers.BigNumber | undefined>;
};
//# sourceMappingURL=useLayerZeroFee.d.ts.map