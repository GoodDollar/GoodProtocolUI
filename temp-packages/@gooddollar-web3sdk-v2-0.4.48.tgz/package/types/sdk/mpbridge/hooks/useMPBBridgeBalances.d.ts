import { MPBBridgeReadOnlyUrls } from "../types";
export declare const useMPBBridgeBalances: (readOnlyUrls?: MPBBridgeReadOnlyUrls) => {
    balancesByChain: {
        fuse: import("@usedapp/core").CurrencyValue;
        celo: import("@usedapp/core").CurrencyValue;
        mainnet: import("@usedapp/core").CurrencyValue;
        xdc: import("@usedapp/core").CurrencyValue;
    };
};
//# sourceMappingURL=useMPBBridgeBalances.d.ts.map