import { IGoodDollar } from "@gooddollar/goodprotocol/types";
import { MPBBridgeReadOnlyUrls } from "../types";
export declare const useMPBG$TokenContract: (chainId?: number, readOnly?: boolean, readOnlyUrls?: MPBBridgeReadOnlyUrls) => IGoodDollar | null;
//# sourceMappingURL=useMPBG$TokenContract.d.ts.map