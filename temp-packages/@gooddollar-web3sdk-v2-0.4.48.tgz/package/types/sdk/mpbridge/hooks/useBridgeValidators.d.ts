import { ethers } from "ethers";
import { BridgeRequest } from "../types";
import { BridgeProvider } from "../constants";
export declare const useBridgeValidators: (account: string | undefined | null, gdContract: any, bridgeContract: ethers.Contract | null, bridgeProvider: BridgeProvider, tokenDecimals: number | undefined, readOnlyProvider: ethers.providers.Provider | undefined) => {
    validateBridgeTransaction: (bridgeRequest: BridgeRequest, fees: any) => Promise<boolean>;
};
//# sourceMappingURL=useBridgeValidators.d.ts.map