import { ethers } from "ethers";
import { TransactionStatus } from "@usedapp/core";
export type MPBBridgeReadOnlyUrls = Partial<Record<number, string>>;
export declare enum BridgeService {
    AXELAR = 0,
    LAYERZERO = 1
}
export declare const getMPBContractAddress: (chainId: number, envName: string) => string | undefined;
export type MPBBridgeData = {
    bridgeFees: {
        nativeFee: ethers.BigNumber | null;
        zroFee: ethers.BigNumber | null;
    };
    bridgeLimits: {
        minAmount: ethers.BigNumber;
        maxAmount: ethers.BigNumber;
    } | null;
    protocolFeePercent: number | null;
    isLoading: boolean;
    error: string | null;
    validation: {
        isValid: boolean;
        reason: string;
        errorMessage?: string;
        canBridge: boolean;
        hasAllowance: boolean;
    };
    allowance: ethers.BigNumber | undefined;
};
export type BridgeRequest = {
    amount: string;
    sourceChainId: number;
    targetChainId: number;
    target?: string;
    bridging?: boolean;
};
export type BridgeHistoryItem = {
    data: {
        id: string;
        from: string;
        target: string;
        amount: ethers.BigNumber;
        sourceChainId: number;
        targetChainId: number;
        bridge: number;
        timestamp?: number;
    };
    executedEvent?: any;
    amount: string;
    sourceChain: string;
    targetChain: string;
    bridgeService: string;
    status: "Completed" | "Pending";
    timestamp: number;
    transactionHash: string;
    blockNumber: number;
};
export type UseMPBBridgeReturn = {
    sendMPBBridgeRequest: (amount: string, sourceChain: string, targetChain: string, target?: string) => Promise<void>;
    bridgeRequestStatus: TransactionStatus;
    bridgeStatus: Partial<TransactionStatus> | undefined;
    bridgeRequest: BridgeRequest | undefined;
    isSwitchingChain: boolean;
};
//# sourceMappingURL=types.d.ts.map