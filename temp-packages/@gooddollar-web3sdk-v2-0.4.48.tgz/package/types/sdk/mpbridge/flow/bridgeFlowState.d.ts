import { DeriveMPBBridgeFlowStateParams, MPBBridgeFlowSnapshot } from "./types";
export declare const isUserRejectionError: (message?: string) => boolean;
export declare const deriveMPBBridgeFlowState: (params: DeriveMPBBridgeFlowStateParams) => MPBBridgeFlowSnapshot;
//# sourceMappingURL=bridgeFlowState.d.ts.map