import { UseMPBBridgeFlowParams } from "./types";
export declare const useMPBBridgeFlow: ({ bridgeProvider, sourceChain, targetChain, amountWei, account, canSubmit, hasFeeError, readOnlyUrls }?: UseMPBBridgeFlowParams) => {
    flow: import("./types").MPBBridgeFlowSnapshot;
    bridgeData: import("..").MPBBridgeData & {
        validation: import("../hooks/useGetMPBBridgeData").ValidationResult;
    };
    resetFlow: () => void;
    sendMPBBridgeRequest: (amount: string, sourceChain: string, targetChain: string, target?: string | undefined) => Promise<void>;
    bridgeRequestStatus: import("@usedapp/core").TransactionStatus;
    bridgeStatus: Partial<import("@usedapp/core").TransactionStatus> | undefined;
    bridgeRequest: import("..").BridgeRequest | undefined;
    isSwitchingChain: boolean;
};
//# sourceMappingURL=useMPBBridgeFlow.d.ts.map