export declare const BRIDGE_FEES_CACHE_DURATION_MS: number;
export declare const fetchBridgeFees: (retries?: number, delay?: number) => Promise<any>;
export declare const clearBridgeFeesCache: () => void;
export declare const convertFeeToWei: (fee: string) => string;
export declare const convertFeeFromWei: (weiAmount: string) => string;
export declare const getLayerZeroExplorerLink: (txHash: string, chainId: number) => string;
export declare const getAxelarExplorerLink: (txHash: string, chainId: number) => string;
//# sourceMappingURL=api.d.ts.map